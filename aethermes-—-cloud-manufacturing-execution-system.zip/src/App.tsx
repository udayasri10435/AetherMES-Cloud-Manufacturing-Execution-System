/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MesProvider } from './context/MesContext';
import { Header } from './components/Header';
import { ShopfloorCockpit } from './components/ShopfloorCockpit';
import { OeeAnalytics } from './components/OeeAnalytics';
import { QualitySpcView } from './components/QualitySpcView';
import { TraceabilityExplorer } from './components/TraceabilityExplorer';
import { OperatorStationView } from './components/OperatorStationView';
import { DisruptionComparisonModal } from './components/DisruptionComparisonModal';
import { NewWorkOrderModal } from './components/NewWorkOrderModal';
import { NcrModal } from './components/NcrModal';

function MesAppContent() {
  const [activeTab, setActiveTab] = useState<string>('floor');
  const [isCompareOpen, setIsCompareOpen] = useState<boolean>(false);
  const [isNewWoOpen, setIsNewWoOpen] = useState<boolean>(false);
  const [isNcrOpen, setIsNcrOpen] = useState<boolean>(false);
  const [operatorLineId, setOperatorLineId] = useState<string>('LINE-01');

  const handleOpenOperatorStation = (lineId: string) => {
    setOperatorLineId(lineId);
    setActiveTab('operator');
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans">
      {/* Top Bar strictly following 3-Zone Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewWo={() => setIsNewWoOpen(true)}
        onOpenCompare={() => setIsCompareOpen(true)}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'floor' && (
          <ShopfloorCockpit
            onOpenOperatorStation={handleOpenOperatorStation}
            onOpenNewWo={() => setIsNewWoOpen(true)}
          />
        )}

        {activeTab === 'oee' && <OeeAnalytics />}

        {activeTab === 'quality' && (
          <QualitySpcView onOpenNewNcr={() => setIsNcrOpen(true)} />
        )}

        {activeTab === 'genealogy' && <TraceabilityExplorer />}

        {activeTab === 'operator' && (
          <OperatorStationView initialLineId={operatorLineId} />
        )}
      </main>

      {/* Quiet, Human Editorial Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 px-6 py-4 text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">AetherMES</span>
            <span>·</span>
            <span>Cloud Manufacturing Execution System</span>
            <span>·</span>
            <span>Facility Alpha (Munich High-Tech Campus)</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500">
            <button
              onClick={() => setIsCompareOpen(true)}
              className="hover:text-cyan-400 transition-colors"
            >
              Disrupting SAP ME & Rockwell
            </button>
            <span>·</span>
            <span>IEC 62264 / MESA Compliant</span>
            <span>·</span>
            <span>ISO 9001 / IATF 16949 Gate</span>
          </div>
        </div>
      </footer>

      {/* Dialog Modals */}
      <DisruptionComparisonModal
        isOpen={isCompareOpen}
        onClose={() => setIsCompareOpen(false)}
      />

      <NewWorkOrderModal
        isOpen={isNewWoOpen}
        onClose={() => setIsNewWoOpen(false)}
      />

      <NcrModal
        isOpen={isNcrOpen}
        onClose={() => setIsNcrOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <MesProvider>
      <MesAppContent />
    </MesProvider>
  );
}
