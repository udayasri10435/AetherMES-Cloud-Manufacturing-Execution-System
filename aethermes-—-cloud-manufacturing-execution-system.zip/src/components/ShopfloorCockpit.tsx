import React, { useState } from 'react';
import { useMes } from '../context/MesContext';
import { LineStatus } from '../types/mes';
import {
  Play,
  AlertTriangle,
  RotateCw,
  CheckCircle2,
  Clock,
  Gauge,
  Sliders,
  ChevronRight,
  Sparkles,
  Zap,
} from 'lucide-react';

interface ShopfloorCockpitProps {
  onOpenOperatorStation: (lineId: string) => void;
  onOpenNewWo: () => void;
}

export const ShopfloorCockpit: React.FC<ShopfloorCockpitProps> = ({
  onOpenOperatorStation,
  onOpenNewWo,
}) => {
  const {
    lines,
    activeLineId,
    activeLine,
    activeWorkOrder,
    selectLine,
    setLineStatus,
    triggerMicroStoppage,
    resolveStoppage,
    recordGoodUnit,
    plantOverallOee,
    plantAvailability,
    plantPerformance,
    plantQuality,
    totalProducedShift,
    totalScrapShift,
    firstPassYield,
  } = useMes();

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showStoppageModal, setShowStoppageModal] = useState<boolean>(false);
  const [selectedStoppageReason, setSelectedStoppageReason] = useState<string>('Component Reel Starvation on Feeder 4');

  const filteredLines = lines.filter((line) => {
    if (filterStatus === 'all') return true;
    return line.status === filterStatus;
  });

  const getStatusColor = (status: LineStatus) => {
    switch (status) {
      case 'running':
        return 'text-emerald-400 bg-emerald-950/60 border-emerald-800/80';
      case 'down':
        return 'text-rose-400 bg-rose-950/60 border-rose-800/80';
      case 'changeover':
        return 'text-amber-400 bg-amber-950/60 border-amber-800/80';
      case 'maintenance':
        return 'text-blue-400 bg-blue-950/60 border-blue-800/80';
      default:
        return 'text-slate-400 bg-slate-900 border-slate-700';
    }
  };

  const getStatusLabel = (status: LineStatus) => {
    switch (status) {
      case 'running':
        return 'Running Nominal';
      case 'down':
        return 'Unplanned Down';
      case 'changeover':
        return 'Setup / Changeover';
      case 'maintenance':
        return 'Preventive Maint';
      case 'idle':
        return 'Idle / Starved';
    }
  };

  return (
    <div className="space-y-6">
      {/* Plant Executive Summary Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400 mb-1">Plant OEE</div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold tracking-tight text-white font-mono tabular-nums">
              {plantOverallOee}%
            </span>
            <span className="text-xs text-emerald-400 font-mono">Target: 85%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
            <div
              className={`h-full rounded-full ${plantOverallOee >= 85 ? 'bg-emerald-400' : 'bg-amber-400'}`}
              style={{ width: `${Math.min(100, plantOverallOee)}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400 mb-1">Availability</div>
          <div className="text-2xl font-bold tracking-tight text-white font-mono tabular-nums">
            {plantAvailability}%
          </div>
          <div className="text-xs text-slate-500 mt-2">Planned Runtime Ratio</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400 mb-1">Performance</div>
          <div className="text-2xl font-bold tracking-tight text-white font-mono tabular-nums">
            {plantPerformance}%
          </div>
          <div className="text-xs text-slate-500 mt-2">Ideal vs Actual Speed</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400 mb-1">Quality Rate</div>
          <div className="text-2xl font-bold tracking-tight text-emerald-400 font-mono tabular-nums">
            {plantQuality}%
          </div>
          <div className="text-xs text-slate-500 mt-2">Good Units Ratio</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400 mb-1">Produced Shift</div>
          <div className="text-2xl font-bold tracking-tight text-white font-mono tabular-nums">
            {totalProducedShift.toLocaleString()}
          </div>
          <div className="text-xs text-slate-500 mt-2">Finished Units</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400 mb-1">Scrapped Shift</div>
          <div className="text-2xl font-bold tracking-tight text-rose-400 font-mono tabular-nums">
            {totalScrapShift}
          </div>
          <div className="text-xs text-slate-500 mt-2">Defect Quarantine</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400 mb-1">First Pass Yield</div>
          <div className="text-2xl font-bold tracking-tight text-cyan-400 font-mono tabular-nums">
            {firstPassYield}%
          </div>
          <div className="text-xs text-slate-500 mt-2">Zero Rework Units</div>
        </div>
      </div>

      {/* Main Grid: Work Centers List + Active Traveler Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Work Centers / Lines (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900/50 p-3 rounded-xl border border-slate-800">
            <div>
              <h2 className="text-base font-semibold text-white">Shop Floor Work Centers</h2>
              <div className="text-xs text-slate-400">
                5 active production cells · Real-time edge stream · Zero-install cloud
              </div>
            </div>

            {/* Segmented Filter Buttons */}
            <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-lg border border-slate-700/60">
              <button
                onClick={() => setFilterStatus('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                  filterStatus === 'all'
                    ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All Lines ({lines.length})
              </button>
              <button
                onClick={() => setFilterStatus('running')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                  filterStatus === 'running'
                    ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Running ({lines.filter((l) => l.status === 'running').length})
              </button>
              <button
                onClick={() => setFilterStatus('down')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                  filterStatus === 'down'
                    ? 'bg-rose-500/20 text-rose-300 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Down ({lines.filter((l) => l.status === 'down').length})
              </button>
              <button
                onClick={() => setFilterStatus('changeover')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                  filterStatus === 'changeover'
                    ? 'bg-amber-500/20 text-amber-300 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Setup ({lines.filter((l) => l.status === 'changeover').length})
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {filteredLines.map((line) => {
              const isSelected = line.id === activeLineId;
              const isCycleOverTakt = line.currentCycleSec > line.plannedTaktSec && line.status === 'running';

              return (
                <div
                  key={line.id}
                  onClick={() => selectLine(line.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500/50 shadow-md ring-1 ring-cyan-500/20'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2.5">
                        <span className="font-semibold text-white text-sm">{line.name}</span>
                        <span className="text-xs text-slate-500">·</span>
                        <span className="text-xs text-slate-400">{line.area}</span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                        <span>Work Order:</span>
                        <span className="text-cyan-300 font-mono font-medium">{line.activeWorkOrderId}</span>
                        <span>·</span>
                        <span className="truncate max-w-[240px] text-slate-300">{line.currentStepName}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-0.5 rounded border font-medium ${getStatusColor(line.status)}`}>
                        {getStatusLabel(line.status)}
                      </span>
                    </div>
                  </div>

                  {line.lastAnomaly && (
                    <div className="mt-2.5 p-2 rounded bg-amber-950/20 border border-amber-800/40 text-xs text-amber-300 flex items-center gap-2">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-400" />
                      <span className="truncate">{line.lastAnomaly}</span>
                    </div>
                  )}

                  {/* Telemetry & OEE bar */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-3 border-t border-slate-800/80">
                    <div>
                      <div className="text-[11px] text-slate-500">Takt vs Cycle</div>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span
                          className={`font-mono text-sm font-semibold tabular-nums ${
                            isCycleOverTakt ? 'text-amber-400' : 'text-slate-200'
                          }`}
                        >
                          {line.currentCycleSec}s
                        </span>
                        <span className="text-slate-500 text-xs font-mono">/ {line.plannedTaktSec}s</span>
                      </div>
                    </div>

                    <div>
                      <div className="text-[11px] text-slate-500">Produced / Target</div>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="font-mono text-sm font-semibold text-slate-200 tabular-nums">
                          {line.producedUnits}
                        </span>
                        <span className="text-slate-500 text-xs font-mono">/ {line.targetShiftUnits}</span>
                      </div>
                    </div>

                    <div>
                      <div className="text-[11px] text-slate-500">Line OEE</div>
                      <div className="font-mono text-sm font-semibold text-cyan-400 tabular-nums mt-0.5">
                        {line.oee}%
                      </div>
                    </div>

                    <div>
                      <div className="text-[11px] text-slate-500">Operator</div>
                      <div className="text-xs text-slate-300 truncate mt-0.5" title={line.operator}>
                        {line.operator.split(' ')[0]} {line.operator.split(' ')[1]?.[0]}.
                      </div>
                    </div>
                  </div>

                  {/* Fast Action Footer */}
                  <div className="flex items-center justify-between mt-3 pt-2 text-xs">
                    <div className="flex items-center gap-3 text-slate-400">
                      <span>Temp: {line.stationSensors.tempC}°C</span>
                      <span>·</span>
                      <span>Vib: {line.stationSensors.vibrationMmS} mm/s</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenOperatorStation(line.id);
                        }}
                        className="px-2.5 py-1 text-xs text-cyan-300 hover:text-white bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-800/50 rounded transition-colors flex items-center gap-1"
                      >
                        <span>Open Kiosk</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Active Line Digital Traveler & Execution Deck (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-5">
            <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <div className="text-xs text-slate-400">Active Work Center Deck</div>
                <h3 className="text-base font-bold text-white mt-0.5">{activeLine.name}</h3>
                <div className="text-xs text-slate-400 mt-1">
                  Operator: <span className="text-slate-200">{activeLine.operator}</span>
                </div>
              </div>

              {/* Status Controls */}
              <div className="flex flex-col items-end gap-1.5">
                <span className={`text-xs px-2.5 py-1 rounded border font-medium ${getStatusColor(activeLine.status)}`}>
                  {getStatusLabel(activeLine.status)}
                </span>
                {activeLine.status === 'down' ? (
                  <button
                    onClick={() => resolveStoppage(activeLine.id)}
                    className="px-2.5 py-1 text-xs font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800 rounded hover:bg-emerald-900/60 transition-colors flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Clear Stoppage</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setShowStoppageModal(true)}
                    className="px-2.5 py-1 text-xs font-medium text-rose-300 bg-rose-950/50 border border-rose-800/60 rounded hover:bg-rose-900/50 transition-colors flex items-center gap-1"
                  >
                    <AlertTriangle className="w-3 h-3" />
                    <span>Simulate Stop</span>
                  </button>
                )}
              </div>
            </div>

            {/* Quick 1-tap manual unit registration */}
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg flex items-center justify-between">
              <div>
                <div className="text-xs font-medium text-white">Manual Production Pulse</div>
                <div className="text-[11px] text-slate-400">Trigger edge barcode completion event</div>
              </div>
              <button
                onClick={() => recordGoodUnit(activeLine.id)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Log +1 Good Unit</span>
              </button>
            </div>

            {/* Work Order Info */}
            {activeWorkOrder ? (
              <div className="space-y-4">
                <div className="p-3.5 bg-slate-950/50 border border-slate-800 rounded-lg space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">e-Traveler Order:</span>
                    <span className="font-mono text-cyan-300 font-semibold">{activeWorkOrder.id}</span>
                  </div>
                  <div className="text-sm font-semibold text-white">{activeWorkOrder.partName}</div>
                  <div className="text-xs text-slate-400 flex items-center gap-2">
                    <span className="font-mono text-slate-300">{activeWorkOrder.partNumber}</span>
                    <span>·</span>
                    <span>{activeWorkOrder.revision}</span>
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-2">
                    <span>Lot:</span>
                    <span className="font-mono text-slate-200">{activeWorkOrder.lotNumber}</span>
                    <span>·</span>
                    <span>Due:</span>
                    <span className="text-slate-200">{activeWorkOrder.dueDate}</span>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1.5 pt-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Shift Fulfillment</span>
                      <span className="font-mono text-slate-200 tabular-nums">
                        {activeWorkOrder.completedQty} / {activeWorkOrder.plannedQty} units (
                        {Math.round((activeWorkOrder.completedQty / activeWorkOrder.plannedQty) * 100)}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-cyan-400 h-full rounded-full transition-all"
                        style={{
                          width: `${Math.min(100, (activeWorkOrder.completedQty / activeWorkOrder.plannedQty) * 100)}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Routing Steps / Digital Traveler Checklist */}
                <div>
                  <div className="flex items-center justify-between mb-2.5">
                    <div className="text-xs font-semibold text-slate-300">Operation Routing Sequence</div>
                    <div className="text-[11px] text-slate-500 font-mono">ISO 9001 / IATF 16949 Gate</div>
                  </div>

                  <div className="space-y-2.5">
                    {activeWorkOrder.steps.map((step) => {
                      const isStepPassed = step.status === 'passed';
                      const isStepActive = step.status === 'in_progress';

                      return (
                        <div
                          key={step.id}
                          className={`p-3 rounded-lg border transition-all ${
                            isStepActive
                              ? 'bg-cyan-950/20 border-cyan-600/50'
                              : isStepPassed
                              ? 'bg-slate-950/40 border-slate-800/80 text-slate-300'
                              : 'bg-slate-950/20 border-slate-800/40 text-slate-500'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-start gap-2.5">
                              <div
                                className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-mono font-bold mt-0.5 ${
                                  isStepPassed
                                    ? 'bg-emerald-950 border border-emerald-600 text-emerald-400'
                                    : isStepActive
                                    ? 'bg-cyan-950 border border-cyan-500 text-cyan-300 animate-pulse'
                                    : 'bg-slate-800 text-slate-400'
                                }`}
                              >
                                {isStepPassed ? '✓' : step.stepNumber / 10}
                              </div>
                              <div>
                                <div className="text-xs font-semibold text-white">{step.name}</div>
                                <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                                  <span>Station: {step.station}</span>
                                  {step.timestamp && (
                                    <>
                                      <span>·</span>
                                      <span className="font-mono">{step.timestamp}</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>

                            <span
                              className={`text-[10px] px-2 py-0.5 rounded border uppercase tracking-wider font-semibold font-mono ${
                                isStepPassed
                                  ? 'bg-emerald-950/50 text-emerald-300 border-emerald-800'
                                  : isStepActive
                                  ? 'bg-cyan-950/50 text-cyan-300 border-cyan-800'
                                  : 'bg-slate-900 text-slate-500 border-slate-800'
                              }`}
                            >
                              {step.status}
                            </span>
                          </div>

                          {/* Critical In-line Parameters */}
                          {step.parameters && step.parameters.length > 0 && (
                            <div className="mt-2.5 grid grid-cols-2 gap-2 text-[11px] bg-slate-900/60 p-2 rounded border border-slate-800/60">
                              {step.parameters.map((p, idx) => (
                                <div key={idx} className="space-y-0.5">
                                  <div className="text-slate-400">{p.name}</div>
                                  <div className="font-mono text-slate-200">
                                    {p.actual ? (
                                      <span className={p.passed === false ? 'text-rose-400 font-bold' : 'text-emerald-300'}>
                                        {p.actual} {p.unit}
                                      </span>
                                    ) : (
                                      <span className="text-slate-500">Pending</span>
                                    )}{' '}
                                    <span className="text-slate-500 text-[10px]">(tgt: {p.target})</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* BOM Consumed Lots */}
                <div className="pt-2">
                  <div className="text-xs font-semibold text-slate-300 mb-2">BOM Component Lots Trace</div>
                  <div className="space-y-1.5">
                    {activeWorkOrder.bomComponents.map((bom) => (
                      <div
                        key={bom.componentId}
                        className="flex items-center justify-between text-xs p-2 rounded bg-slate-950/40 border border-slate-800/50"
                      >
                        <div className="truncate max-w-[200px]">
                          <div className="text-slate-200 font-medium">{bom.componentId}</div>
                          <div className="text-[10px] text-slate-400 truncate">{bom.description}</div>
                        </div>
                        <div className="text-right">
                          <span className="font-mono text-cyan-300 text-[11px]">{bom.consumedLot}</span>
                          <div className="text-[10px] text-slate-500">{bom.supplier}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 text-xs">
                No active work order assigned to this cell.
                <button
                  onClick={onOpenNewWo}
                  className="mt-3 block mx-auto px-3 py-1.5 bg-cyan-500/20 text-cyan-300 rounded border border-cyan-800"
                >
                  Dispatch Work Order
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Simulated Stoppage / Downtime Trigger Modal */}
      {showStoppageModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 max-w-md w-full rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  Simulate Line Incident
                </h3>
                <div className="text-xs text-slate-400 mt-1">
                  Trigger an unplanned downtime event on {activeLine.name}
                </div>
              </div>
              <button
                onClick={() => setShowStoppageModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-slate-300 font-medium">Select Incident Reason Code</label>
              {[
                'Component Reel Starvation on Feeder 4',
                'Pneumatic Pressure Drop below 5.0 bar',
                'AOI Camera Calibration Drift (Coplanarity)',
                'Thermal Chamber E-Stop Safety Curtain Interlock',
                'Laser Chiller High-Temp Alarm (>26°C)',
              ].map((reason) => (
                <button
                  key={reason}
                  onClick={() => setSelectedStoppageReason(reason)}
                  className={`w-full text-left p-2.5 rounded-lg text-xs transition-colors border ${
                    selectedStoppageReason === reason
                      ? 'bg-amber-950/40 text-amber-300 border-amber-600/80 font-medium'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {reason}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowStoppageModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  triggerMicroStoppage(activeLine.id, selectedStoppageReason);
                  setShowStoppageModal(false);
                }}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors"
              >
                Trigger Stoppage
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
