import React, { useState, useMemo } from 'react';
import { useMes } from '../context/MesContext';
import {
  ShieldAlert,
  CheckCircle2,
  TrendingDown,
  AlertCircle,
  Plus,
  Activity,
  Layers,
  FileSpreadsheet,
} from 'lucide-react';

interface QualitySpcViewProps {
  onOpenNewNcr: () => void;
}

export const QualitySpcView: React.FC<QualitySpcViewProps> = ({ onOpenNewNcr }) => {
  const { spcData, addSpcMeasurement, defects, ncrs, firstPassYield } = useMes();

  const [newSampleVal, setNewSampleVal] = useState<string>('12.04');
  const [selectedSubgroup, setSelectedSubgroup] = useState<number | null>(null);

  // SPC Parameters for Critical Dimension (e.g. Laser Micro-Weld Penetration Depth in mm)
  const USL = 12.50; // Upper Spec Limit
  const UCL = 12.32; // Upper Control Limit (3-sigma)
  const TARGET = 12.00;
  const LCL = 11.68; // Lower Control Limit (3-sigma)
  const LSL = 11.50; // Lower Spec Limit

  // Compute Process Capability (Cp and Cpk)
  const stats = useMemo(() => {
    if (spcData.length === 0) return { mean: 12.0, stdev: 0.08, cp: 1.67, cpk: 1.55 };

    const values = spcData.map((s) => s.value);
    const sum = values.reduce((a, b) => a + b, 0);
    const mean = sum / values.length;

    const variance = values.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / (values.length - 1);
    const stdev = Math.sqrt(variance) || 0.08;

    const cp = (USL - LSL) / (6 * stdev);
    const cpkUpper = (USL - mean) / (3 * stdev);
    const cpkLower = (mean - LSL) / (3 * stdev);
    const cpk = Math.min(cpkUpper, cpkLower);

    return {
      mean: Number(mean.toFixed(3)),
      stdev: Number(stdev.toFixed(3)),
      cp: Number(cp.toFixed(2)),
      cpk: Number(cpk.toFixed(2)),
    };
  }, [spcData]);

  const handleAddSample = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(newSampleVal);
    if (!isNaN(val)) {
      addSpcMeasurement(val);
      setNewSampleVal('12.05');
    }
  };

  // SVG Chart Geometry
  const chartHeight = 220;
  const chartWidth = 640;
  const paddingX = 45;
  const paddingY = 25;

  const minVal = 11.40;
  const maxVal = 12.60;
  const valRange = maxVal - minVal;

  const getY = (val: number) => {
    const norm = (val - minVal) / valRange;
    return chartHeight - paddingY - norm * (chartHeight - 2 * paddingY);
  };

  const getX = (idx: number, total: number) => {
    if (total <= 1) return paddingX;
    return paddingX + (idx / (total - 1)) * (chartWidth - 2 * paddingX);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-base font-semibold text-white">Quality Engineering & Statistical Process Control (SPC)</h2>
          <div className="text-xs text-slate-400">
            Real-time in-line dimensional verification · Western Electric rule detection · First Pass Yield
          </div>
        </div>

        <button
          onClick={onOpenNewNcr}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm whitespace-nowrap"
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Log Non-Conformance (NCR)</span>
        </button>
      </div>

      {/* Quality Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400">First Pass Yield (FPY)</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums mt-1">
            {firstPassYield}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Zero-rework units at final gate</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400">Process Capability (Cpk)</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-cyan-300 tabular-nums">{stats.cpk}</span>
            <span className="text-xs text-slate-400 font-mono">Cp: {stats.cp}</span>
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            {stats.cpk >= 1.33 ? 'Capability ≥ 1.33 (Capable)' : 'Below 1.33 Target'}
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400">Subgroup Mean (X̄)</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums mt-1">
            {stats.mean} mm
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Nominal Target: {TARGET.toFixed(2)} mm</div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs text-slate-400">Open Non-Conformances</div>
          <div className="text-2xl font-bold font-mono text-rose-400 tabular-nums mt-1">
            {ncrs.filter((n) => n.status !== 'closed').length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {ncrs.filter((n) => n.severity === 'critical').length} Critical severity
          </div>
        </div>
      </div>

      {/* Main Grid: SPC Control Chart (7 cols) + Defect Pareto (5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* SPC Chart */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <div className="text-xs font-semibold text-cyan-400">Feature Variable: Laser Weld Penetration Depth</div>
              <h3 className="text-sm font-bold text-white mt-0.5">X-Bar Run Chart with 3-Sigma Limits</h3>
            </div>
            <div className="text-xs font-mono text-slate-400">
              USL: {USL}mm · LSL: {LSL}mm
            </div>
          </div>

          {/* SVG Control Chart */}
          <div className="relative overflow-x-auto bg-slate-950/70 p-2 rounded-lg border border-slate-800/80">
            <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto">
              {/* Grid Lines */}
              {/* USL Line (Red dashed) */}
              <line x1={paddingX} y1={getY(USL)} x2={chartWidth - paddingX} y2={getY(USL)} stroke="#ef4444" strokeDasharray="4 4" strokeWidth="1" />
              <text x={chartWidth - paddingX + 4} y={getY(USL) + 3} fill="#ef4444" fontSize="9" fontFamily="monospace">USL {USL}</text>

              {/* UCL Line (Amber solid) */}
              <line x1={paddingX} y1={getY(UCL)} x2={chartWidth - paddingX} y2={getY(UCL)} stroke="#f59e0b" strokeWidth="1.2" />
              <text x={chartWidth - paddingX + 4} y={getY(UCL) + 3} fill="#f59e0b" fontSize="9" fontFamily="monospace">UCL {UCL}</text>

              {/* Target / Nominal Mean (Cyan dashed) */}
              <line x1={paddingX} y1={getY(TARGET)} x2={chartWidth - paddingX} y2={getY(TARGET)} stroke="#06b6d4" strokeDasharray="3 3" strokeWidth="1.2" />
              <text x={chartWidth - paddingX + 4} y={getY(TARGET) + 3} fill="#06b6d4" fontSize="9" fontFamily="monospace">TGT {TARGET}</text>

              {/* LCL Line (Amber solid) */}
              <line x1={paddingX} y1={getY(LCL)} x2={chartWidth - paddingX} y2={getY(LCL)} stroke="#f59e0b" strokeWidth="1.2" />
              <text x={chartWidth - paddingX + 4} y={getY(LCL) + 3} fill="#f59e0b" fontSize="9" fontFamily="monospace">LCL {LCL}</text>

              {/* LSL Line (Red dashed) */}
              <line x1={paddingX} y1={getY(LSL)} x2={chartWidth - paddingX} y2={getY(LSL)} stroke="#ef4444" strokeDasharray="4 4" strokeWidth="1" />
              <text x={chartWidth - paddingX + 4} y={getY(LSL) + 3} fill="#ef4444" fontSize="9" fontFamily="monospace">LSL {LSL}</text>

              {/* Data Trend Line */}
              <polyline
                fill="none"
                stroke="#38bdf8"
                strokeWidth="1.8"
                points={spcData.map((d, i) => `${getX(i, spcData.length)},${getY(d.value)}`).join(' ')}
              />

              {/* Data Sample Dots */}
              {spcData.map((d, i) => {
                const cx = getX(i, spcData.length);
                const cy = getY(d.value);
                const isSelected = selectedSubgroup === d.sampleIndex;

                return (
                  <g key={d.id} className="cursor-pointer" onClick={() => setSelectedSubgroup(d.sampleIndex)}>
                    <circle
                      cx={cx}
                      cy={cy}
                      r={d.isViolation ? 5 : isSelected ? 4.5 : 3}
                      fill={d.isViolation ? '#f43f5e' : '#38bdf8'}
                      stroke={d.isViolation ? '#ffe4e6' : '#0284c7'}
                      strokeWidth={d.isViolation ? 2 : 1}
                    />
                    {d.isViolation && (
                      <text x={cx - 10} y={cy - 9} fill="#fb7185" fontSize="8" fontWeight="bold" fontFamily="monospace">
                        FAIL
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Interactive SPC Sample Ingestion Bar */}
          <form onSubmit={handleAddSample} className="flex items-center gap-3 bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div className="text-xs text-slate-300 font-medium whitespace-nowrap">Simulate CMM Gauge Input:</div>
            <input
              type="number"
              step="0.01"
              value={newSampleVal}
              onChange={(e) => setNewSampleVal(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-white font-mono text-xs px-3 py-1.5 rounded w-28 focus:outline-none focus:border-cyan-500 tabular-nums"
              placeholder="12.00"
            />
            <span className="text-xs text-slate-400 font-mono">mm</span>
            <button
              type="submit"
              className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors whitespace-nowrap"
            >
              Push Sample
            </button>
            <div className="text-[11px] text-slate-500 ml-auto hidden sm:block">
              Tip: Enter &gt; 12.32mm to trigger 3σ rule alarm
            </div>
          </form>

          {/* Western Electric Violation Notice */}
          {spcData.some((s) => s.isViolation) && (
            <div className="p-3 bg-rose-950/30 border border-rose-800/60 rounded-lg text-xs text-rose-300 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-rose-200">Western Electric Rule 1 Out-of-Control Condition Detected</div>
                <div className="text-[11px] text-rose-400 mt-0.5">
                  Sample S9 measured at 12.35 mm exceeded the Upper Control Limit (UCL = 12.32 mm). Automatic containment quarantine flagged for Lot LOT-2026-09A.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Defect Pareto Analysis (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white">Defect Pareto Breakdown (80/20 Rule)</h3>
              <p className="text-xs text-slate-400 mt-0.5">Ranked failure modes sorted by frequency</p>
            </div>
            <span className="text-xs text-cyan-400 font-mono">Shift Log</span>
          </div>

          <div className="space-y-3 pt-1">
            {defects.map((defect) => (
              <div key={defect.id} className="space-y-1.5 p-2 rounded bg-slate-950/40 border border-slate-800/50">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-200 font-medium truncate max-w-[210px]">{defect.category}</span>
                  <div className="flex items-center gap-2 font-mono">
                    <span className="text-rose-400 font-semibold">{defect.count} defects</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-300">{defect.percentage}%</span>
                  </div>
                </div>

                {/* Pareto dual bar (frequency + cumulative) */}
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden flex">
                  <div className="bg-rose-500 h-full rounded-full" style={{ width: `${defect.percentage}%` }} />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800 text-[11px] text-slate-400">
            Top 3 failure modes account for <span className="text-white font-mono font-semibold">79.3%</span> of all shift rejects. Closed-loop SPI stencil cleaning scheduled to eliminate solder bridging.
          </div>
        </div>
      </div>

      {/* Non-Conformance Register (NCR) Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white">Active Non-Conformance Reports (NCR) & CAPA</h3>
            <p className="text-xs text-slate-400 mt-0.5">Formal discrepancy containment log per ISO 13485 & IATF 16949</p>
          </div>
          <span className="text-xs text-slate-400 font-mono">{ncrs.length} Records</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3 font-semibold">NCR ID</th>
                <th className="py-2.5 px-3 font-semibold">Timestamp</th>
                <th className="py-2.5 px-3 font-semibold">Work Order</th>
                <th className="py-2.5 px-3 font-semibold">Defect Description</th>
                <th className="py-2.5 px-3 font-semibold">Qty</th>
                <th className="py-2.5 px-3 font-semibold">Severity</th>
                <th className="py-2.5 px-3 font-semibold">Containment Action</th>
                <th className="py-2.5 px-3 font-semibold">Disposition</th>
                <th className="py-2.5 px-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {ncrs.map((ncr) => (
                <tr key={ncr.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 text-cyan-300 font-semibold">{ncr.id}</td>
                  <td className="py-2.5 px-3 text-slate-400 text-[11px]">{ncr.timestamp}</td>
                  <td className="py-2.5 px-3 text-slate-300">{ncr.workOrderId}</td>
                  <td className="py-2.5 px-3 text-white font-sans">{ncr.defectCategory}</td>
                  <td className="py-2.5 px-3 text-slate-200 tabular-nums">{ncr.qtyAffected} pcs</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded border ${
                        ncr.severity === 'critical'
                          ? 'bg-rose-950/60 text-rose-300 border-rose-800'
                          : 'bg-amber-950/60 text-amber-300 border-amber-800'
                      }`}
                    >
                      {ncr.severity}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 font-sans max-w-xs truncate" title={ncr.containmentAction}>
                    {ncr.containmentAction}
                  </td>
                  <td className="py-2.5 px-3 uppercase text-[10px] font-semibold text-slate-300">
                    {ncr.disposition}
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded border ${
                        ncr.status === 'closed'
                          ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                          : ncr.status === 'contained'
                          ? 'bg-blue-950/60 text-blue-300 border-blue-800'
                          : 'bg-rose-950/60 text-rose-300 border-rose-800'
                      }`}
                    >
                      {ncr.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
