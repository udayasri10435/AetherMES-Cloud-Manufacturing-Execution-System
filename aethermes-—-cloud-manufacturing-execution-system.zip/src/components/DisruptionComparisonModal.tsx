import React from 'react';
import { Check, X, Zap, ShieldAlert, Cpu, DollarSign, Clock, Layers } from 'lucide-react';

interface DisruptionComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DisruptionComparisonModal: React.FC<DisruptionComparisonModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const comparisonRows = [
    {
      dimension: 'Architecture & Deployment',
      aether: 'Pure Web Cloud + Edge Gateway. Live in 48 hours. Zero local servers.',
      legacy: 'Heavy On-Premises Oracle/SQL servers. 9–18 month SAP/Rockwell implementation.',
      impact: '10x faster time-to-value',
    },
    {
      dimension: 'Shop Floor Operator UI',
      aether: 'Responsive touch-first web interface designed for rugged tablets & tablets.',
      legacy: 'Clunky 2000s Java Applets, ActiveX, and Windows Thick Clients (FactoryTalk View).',
      impact: 'Zero operator training friction',
    },
    {
      dimension: 'Telemetry & OEE Sync',
      aether: 'Sub-second real-time streaming over MQTT / WebSockets. Live loss waterfall.',
      legacy: 'Batch SAP IDoc sync every 15–60 minutes. Delayed post-mortem reporting.',
      impact: 'Immediate micro-stoppage prevention',
    },
    {
      dimension: 'Lot Traceability & Recall',
      aether: 'Instant forward/backward graph query. 1-click Electronic Lot Quarantine.',
      legacy: 'Fragmented batch tables requiring custom ABAP reports & manual warehouse locks.',
      impact: 'Eliminates multi-million dollar mass recalls',
    },
    {
      dimension: 'Routing & Recipe Agility',
      aether: 'Visual zero-code e-Traveler reconfiguration in minutes by process engineers.',
      legacy: 'Months of expensive systems integrator (Rockwell/SAP) consulting tickets.',
      impact: 'Supports agile high-mix low-volume lines',
    },
    {
      dimension: 'Total Cost of Ownership (TCO)',
      aether: 'Predictable per-line cloud subscription. Automated OTA updates included.',
      legacy: '$1.5M - $5M CAPEX license + $300k/yr annual maintenance + heavy on-site hardware.',
      impact: '80% TCO reduction',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 max-w-4xl w-full rounded-2xl p-6 sm:p-8 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="text-xs font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" />
              <span>Architectural Disruption Thesis</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">
              Why Cloud MES Replaces Legacy SAP ME & Rockwell FactoryTalk
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Industrial operations are transitioning from monolithic on-prem client-server dinosaurs to real-time cloud-native platforms.
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-base p-1">
            ✕
          </button>
        </div>

        {/* Feature Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-3 px-3 font-semibold w-1/4">Evaluation Dimension</th>
                <th className="py-3 px-3 font-semibold text-cyan-300 w-1/3 bg-cyan-950/20 rounded-t-lg">
                  AetherMES (Modern Cloud)
                </th>
                <th className="py-3 px-3 font-semibold text-slate-400 w-1/3">
                  Legacy (SAP ME / Rockwell)
                </th>
                <th className="py-3 px-3 font-semibold text-emerald-400">Advantage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {comparisonRows.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3.5 px-3 font-medium text-slate-200">{row.dimension}</td>
                  <td className="py-3.5 px-3 text-cyan-100 bg-cyan-950/10 font-medium">
                    <div className="flex items-start gap-1.5">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{row.aether}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-3 text-slate-400">
                    <div className="flex items-start gap-1.5">
                      <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <span>{row.legacy}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-3 font-mono font-semibold text-emerald-400 text-[11px] whitespace-nowrap">
                    {row.impact}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="text-slate-400">
            Open standard APIs: Fully integrates with existing ERPs (SAP S/4HANA, NetSuite) while executing shop floor logic at wire speed.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors whitespace-nowrap"
          >
            Close Analysis
          </button>
        </div>
      </div>
    </div>
  );
};
