import React, { useState } from 'react';
import { useMes } from '../context/MesContext';
import { PriorityLevel } from '../types/mes';
import { Plus, Check, Calendar, Layers } from 'lucide-react';

interface NewWorkOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewWorkOrderModal: React.FC<NewWorkOrderModalProps> = ({ isOpen, onClose }) => {
  const { lines, dispatchWorkOrder } = useMes();

  const [partSku, setPartSku] = useState<string>('BMS-HV-800V');
  const [partName, setPartName] = useState<string>('800V High-Efficiency Battery Management Unit');
  const [revision, setRevision] = useState<string>('Rev E.1 (ISO 26262)');
  const [plannedQty, setPlannedQty] = useState<number>(600);
  const [targetTaktSec, setTargetTaktSec] = useState<number>(20.0);
  const [priority, setPriority] = useState<PriorityLevel>('high');
  const [assignedLineId, setAssignedLineId] = useState<string>('LINE-01');
  const [dueDate, setDueDate] = useState<string>('2026-10-12');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    dispatchWorkOrder({
      partNumber: partSku,
      partName,
      revision,
      plannedQty,
      targetTaktSec,
      priority,
      lineId: assignedLineId,
      dueDate,
    });
    onClose();
  };

  const handleSelectPreset = (sku: string, name: string, rev: string, takt: number) => {
    setPartSku(sku);
    setPartName(name);
    setRevision(rev);
    setTargetTaktSec(takt);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 max-w-lg w-full rounded-2xl p-6 space-y-5 shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-cyan-400" />
              Dispatch New Work Order (e-Traveler)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Create an agile production routing batch and release to shop floor
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-base">
            ✕
          </button>
        </div>

        {/* Quick Presets */}
        <div className="space-y-1.5">
          <div className="text-[11px] text-slate-400 font-medium">Quick SKU Catalog:</div>
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => handleSelectPreset('BMS-HV-800V', '800V High-Efficiency Battery Management Unit', 'Rev E.1', 20.0)}
              className="text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
            >
              800V BMS Unit
            </button>
            <button
              type="button"
              onClick={() => handleSelectPreset('INV-GAN-400', 'GaN Fast-Switching Traction Inverter', 'Rev B.0', 28.0)}
              className="text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
            >
              GaN Traction Inverter
            </button>
            <button
              type="button"
              onClick={() => handleSelectPreset('AVION-FC-3', 'ASIL-D Redundant Flight Controller', 'Rev F.4', 45.0)}
              className="text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
            >
              Avionics Flight PC
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Part SKU / Number</label>
              <input
                type="text"
                required
                value={partSku}
                onChange={(e) => setPartSku(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-white font-mono px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-slate-300 font-medium block mb-1">Revision / Spec</label>
              <input
                type="text"
                required
                value={revision}
                onChange={(e) => setRevision(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-300 font-medium block mb-1">Product Description</label>
            <input
              type="text"
              required
              value={partName}
              onChange={(e) => setPartName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Planned Qty</label>
              <input
                type="number"
                min="10"
                max="10000"
                value={plannedQty}
                onChange={(e) => setPlannedQty(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-white font-mono px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500 tabular-nums"
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Target Takt (sec)</label>
              <input
                type="number"
                step="0.5"
                value={targetTaktSec}
                onChange={(e) => setTargetTaktSec(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-white font-mono px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500 tabular-nums"
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500 font-medium"
              >
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="normal">Normal</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Assigned Cell / Line</label>
              <select
                value={assignedLineId}
                onChange={(e) => setAssignedLineId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500"
              >
                {lines.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Fulfillment Due Date</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Release to Line</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
