import React, { useState } from 'react';
import { useMes } from '../context/MesContext';
import { ShieldAlert, Check } from 'lucide-react';

interface NcrModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NcrModal: React.FC<NcrModalProps> = ({ isOpen, onClose }) => {
  const { workOrders, logNcr } = useMes();

  const [selectedWoId, setSelectedWoId] = useState<string>(workOrders[0]?.id || 'WO-8821');
  const [defectCategory, setDefectCategory] = useState<string>('Terminal Pin Misalignment / Coplanarity');
  const [qtyAffected, setQtyAffected] = useState<number>(10);
  const [severity, setSeverity] = useState<'critical' | 'major' | 'minor'>('major');
  const [containmentAction, setContainmentAction] = useState<string>(
    'Segregated pallet at incoming gate; issued alert to Line Lead; adjusted optical calibration offset.'
  );
  const [disposition, setDisposition] = useState<'scrap' | 'rework' | 'vendor_return' | 'concession'>('rework');
  const [engineerSignOff, setEngineerSignOff] = useState<string>('Dr. Kimberly Zhao (Lead Quality Eng)');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const wo = workOrders.find((w) => w.id === selectedWoId);
    logNcr({
      workOrderId: selectedWoId,
      lotNumber: wo?.lotNumber || 'LOT-2026-09A',
      defectCategory,
      qtyAffected,
      severity,
      status: 'investigating',
      containmentAction,
      disposition,
      engineerSignOff,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              File Non-Conformance Report (NCR) & CAPA
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Auditable containment documentation under ISO 9001 / IATF 16949
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-base">
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Work Order / Traveler</label>
              <select
                value={selectedWoId}
                onChange={(e) => setSelectedWoId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500 font-mono"
              >
                {workOrders.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.id} ({w.partNumber})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Severity Rating</label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500 font-medium"
              >
                <option value="critical">Critical (Safety / ASIL Violation)</option>
                <option value="major">Major (Functional Non-conformance)</option>
                <option value="minor">Minor (Cosmetic / Low Risk)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-slate-300 font-medium block mb-1">Defect Category / Failure Mode</label>
            <input
              type="text"
              required
              value={defectCategory}
              onChange={(e) => setDefectCategory(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Qty Affected (pcs)</label>
              <input
                type="number"
                min="1"
                max="5000"
                value={qtyAffected}
                onChange={(e) => setQtyAffected(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-white font-mono px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500 tabular-nums"
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Disposition Recommendation</label>
              <select
                value={disposition}
                onChange={(e) => setDisposition(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500 uppercase font-mono font-medium"
              >
                <option value="rework">Rework & Re-inspect</option>
                <option value="scrap">Scrap & Purge</option>
                <option value="vendor_return">Return to Supplier</option>
                <option value="concession">Engineer Concession</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-slate-300 font-medium block mb-1">Immediate Containment Action</label>
            <textarea
              rows={2}
              required
              value={containmentAction}
              onChange={(e) => setContainmentAction(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="text-slate-300 font-medium block mb-1">Quality Lead Digital Sign-off</label>
            <input
              type="text"
              required
              value={engineerSignOff}
              onChange={(e) => setEngineerSignOff(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white px-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Log Formal Discrepancy</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
