import React, { useState, useMemo } from 'react';
import { useMes } from '../context/MesContext';
import {
  TrendingUp,
  Clock,
  Gauge,
  CheckCircle2,
  AlertTriangle,
  Zap,
  DollarSign,
  ArrowRight,
  Filter,
} from 'lucide-react';

export const OeeAnalytics: React.FC = () => {
  const {
    lines,
    activeLineId,
    selectLine,
    sixBigLosses,
    plantOverallOee,
    plantAvailability,
    plantPerformance,
    plantQuality,
  } = useMes();

  const selectedLine = useMemo(() => {
    return lines.find((l) => l.id === activeLineId) || lines[0];
  }, [lines, activeLineId]);

  // What-If Simulation State
  const [changeoverReductionMin, setChangeoverReductionMin] = useState<number>(15);
  const [microStopReductionPercent, setMicroStopReductionPercent] = useState<number>(35);
  const [scrapReductionPercent, setScrapReductionPercent] = useState<number>(40);

  // Calculate What-If Projected Gains
  const projectedMetrics = useMemo(() => {
    const plannedShiftMin = 480;
    // Current lost minutes
    const currentDownMin = selectedLine.downtimeMinutes;
    // Recovered minutes from changeover & micro-stops
    const recoveredMin = changeoverReductionMin + (34 * (microStopReductionPercent / 100));
    const newDownMin = Math.max(0, currentDownMin - recoveredMin);
    const newAvailability = Number((((plannedShiftMin - newDownMin) / plannedShiftMin) * 100).toFixed(1));
    
    // Quality improvement
    const currentScrap = selectedLine.scrappedUnits;
    const newScrap = Math.round(currentScrap * (1 - scrapReductionPercent / 100));
    const totalUnits = selectedLine.producedUnits + newScrap;
    const newQuality = Number(((selectedLine.producedUnits / totalUnits) * 100).toFixed(1));

    const newPerformance = Math.min(99.5, selectedLine.performance + 1.8);
    const newOee = Number(((newAvailability * newPerformance * newQuality) / 10000).toFixed(1));
    const oeeDelta = Number((newOee - selectedLine.oee).toFixed(1));

    // Approximate financial gain: $420/hr manufacturing cost + unit value
    const annualGains = Math.round(recoveredMin * 6.5 * 260 * 14.5);

    return {
      newAvailability: Math.min(99.8, newAvailability),
      newQuality: Math.min(99.9, newQuality),
      newOee: Math.min(99.9, newOee),
      oeeDelta,
      annualGains,
      extraUnitsPerShift: Math.round(recoveredMin * (60 / selectedLine.plannedTaktSec)),
    };
  }, [selectedLine, changeoverReductionMin, microStopReductionPercent, scrapReductionPercent]);

  return (
    <div className="space-y-6">
      {/* Header and Line Selector */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-base font-semibold text-white">Overall Equipment Effectiveness (OEE) Engine</h2>
          <div className="text-xs text-slate-400">
            Real-time loss accounting · Six Big Losses breakdown · Continuous improvement modeling
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Work Center:</span>
          <select
            value={activeLineId}
            onChange={(e) => selectLine(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-xs text-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-500 font-medium"
          >
            {lines.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name} ({l.oee}% OEE)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Triad Breakdown: Availability x Performance x Quality = OEE */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Availability */}
        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Availability (A)</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-white tabular-nums">
            {selectedLine.availability}%
          </div>
          <div className="text-xs text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>Planned Production Time:</span>
              <span className="font-mono text-slate-200">480 min</span>
            </div>
            <div className="flex justify-between">
              <span>Actual Operating Time:</span>
              <span className="font-mono text-slate-200">{480 - selectedLine.downtimeMinutes} min</span>
            </div>
            <div className="flex justify-between">
              <span>Total Down / Setup:</span>
              <span className="font-mono text-rose-400">{selectedLine.downtimeMinutes} min</span>
            </div>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${selectedLine.availability}%` }} />
          </div>
        </div>

        {/* Performance */}
        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Performance (P)</span>
            <Gauge className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-white tabular-nums">
            {selectedLine.performance}%
          </div>
          <div className="text-xs text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>Ideal Takt Time:</span>
              <span className="font-mono text-slate-200">{selectedLine.plannedTaktSec} sec/pc</span>
            </div>
            <div className="flex justify-between">
              <span>Actual Avg Cycle:</span>
              <span className="font-mono text-slate-200">{selectedLine.currentCycleSec} sec/pc</span>
            </div>
            <div className="flex justify-between">
              <span>Cycle Speed Loss:</span>
              <span className="font-mono text-amber-400">
                {selectedLine.currentCycleSec > selectedLine.plannedTaktSec
                  ? `+${(selectedLine.currentCycleSec - selectedLine.plannedTaktSec).toFixed(1)}s`
                  : 'Nominal'}
              </span>
            </div>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-emerald-400 h-full rounded-full" style={{ width: `${selectedLine.performance}%` }} />
          </div>
        </div>

        {/* Quality */}
        <div className="bg-slate-900/80 border border-slate-800 p-5 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Quality Rate (Q)</span>
            <CheckCircle2 className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-white tabular-nums">
            {selectedLine.quality}%
          </div>
          <div className="text-xs text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>Total Units Counted:</span>
              <span className="font-mono text-slate-200">{selectedLine.producedUnits + selectedLine.scrappedUnits}</span>
            </div>
            <div className="flex justify-between">
              <span>Passed Conformance:</span>
              <span className="font-mono text-emerald-400">{selectedLine.producedUnits} pcs</span>
            </div>
            <div className="flex justify-between">
              <span>Scrapped / Defective:</span>
              <span className="font-mono text-rose-400">{selectedLine.scrappedUnits} pcs</span>
            </div>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div className="bg-purple-400 h-full rounded-full" style={{ width: `${selectedLine.quality}%` }} />
          </div>
        </div>

        {/* Overall OEE */}
        <div className="bg-slate-900/90 border border-cyan-500/30 p-5 rounded-xl space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">Total Line OEE</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-4xl font-extrabold font-mono text-cyan-300 tabular-nums">
            {selectedLine.oee}%
          </div>
          <div className="text-xs text-slate-400">
            Formula: <span className="font-mono text-slate-300">A ({selectedLine.availability}%) × P ({selectedLine.performance}%) × Q ({selectedLine.quality}%)</span>
          </div>
          <div className="pt-2 text-xs flex items-center justify-between border-t border-slate-800">
            <span className="text-slate-400">World-Class Target:</span>
            <span className={`font-mono font-bold ${selectedLine.oee >= 85 ? 'text-emerald-400' : 'text-amber-400'}`}>
              85.0% {selectedLine.oee >= 85 ? '(Met)' : '(-' + (85.0 - selectedLine.oee).toFixed(1) + '%)'}
            </span>
          </div>
        </div>
      </div>

      {/* Six Big Losses Breakdown (TPM Standard) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-white">Six Big Losses Accounting (TPM Standard)</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Quantified root-cause losses draining line productivity this shift
              </p>
            </div>
            <span className="text-xs text-slate-500 font-mono">Shift 08:00 - 16:00</span>
          </div>

          <div className="space-y-3 pt-2">
            {sixBigLosses.map((loss, idx) => {
              const categoryColor =
                loss.category === 'breakdown'
                  ? 'bg-rose-500 text-rose-400'
                  : loss.category === 'setup_changeover'
                  ? 'bg-amber-500 text-amber-400'
                  : loss.category === 'minor_stoppage'
                  ? 'bg-orange-500 text-orange-400'
                  : loss.category === 'reduced_speed'
                  ? 'bg-yellow-500 text-yellow-400'
                  : 'bg-purple-500 text-purple-400';

              return (
                <div key={loss.category} className="space-y-1.5 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/60">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-slate-500">{idx + 1}.</span>
                      <span className="font-medium text-slate-200">{loss.name}</span>
                      <span className="text-slate-500 text-[10px] font-mono">[{loss.reasonCode}]</span>
                    </div>
                    <div className="flex items-center gap-3 font-mono text-xs">
                      <span className="text-slate-400">{loss.minutes} min lost</span>
                      <span className="text-slate-300 font-bold">-{loss.impactPercent}% OEE</span>
                    </div>
                  </div>

                  {/* Loss bar */}
                  <div className="w-full bg-slate-800/80 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${categoryColor.split(' ')[0]}`}
                      style={{ width: `${Math.min(100, loss.impactPercent * 5)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Shift Time Waterfall Breakdown */}
          <div className="mt-4 pt-3 border-t border-slate-800">
            <div className="text-xs font-medium text-slate-300 mb-2">Shift Time Waterfall (480 Min Base)</div>
            <div className="h-6 flex rounded overflow-hidden text-[10px] font-mono text-center leading-6 font-bold">
              <div className="bg-emerald-600 text-emerald-100 flex-1" title="Productive Run Time (385m)">
                Net Run: 385m (80.2%)
              </div>
              <div className="bg-amber-600 text-amber-100 w-[12%]" title="Changeover / Setup (42m)">
                Setup: 42m
              </div>
              <div className="bg-orange-600 text-orange-100 w-[7%]" title="Micro-stops (34m)">
                Idling: 34m
              </div>
              <div className="bg-rose-700 text-rose-100 w-[5%]" title="Breakdowns (19m)">
                Fail: 19m
              </div>
            </div>
          </div>
        </div>

        {/* Continuous Improvement What-If Kaizen Simulator (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
          <div>
            <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-semibold">
              <TrendingUp className="w-4 h-4" />
              Continuous Improvement (CI) Simulator
            </div>
            <h3 className="text-sm font-bold text-white mt-1">Simulate Kaizen Impact on {selectedLine.name}</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Quantify financial & throughput ROI by eliminating specific shop floor losses
            </p>
          </div>

          <div className="space-y-4 pt-2">
            {/* Slider 1: Changeover time reduction */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">SMED Setup Time Reduction:</span>
                <span className="font-mono text-cyan-300 font-semibold">{changeoverReductionMin} min</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                step="5"
                value={changeoverReductionMin}
                onChange={(e) => setChangeoverReductionMin(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
              <div className="text-[10px] text-slate-500 flex justify-between">
                <span>0 min</span>
                <span>Target: 20 min SMED</span>
                <span>40 min</span>
              </div>
            </div>

            {/* Slider 2: Micro-stop elimination */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">Feeder Jam & Micro-stop Elimination:</span>
                <span className="font-mono text-emerald-300 font-semibold">{microStopReductionPercent}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="80"
                step="5"
                value={microStopReductionPercent}
                onChange={(e) => setMicroStopReductionPercent(Number(e.target.value))}
                className="w-full accent-emerald-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
              <div className="text-[10px] text-slate-500 flex justify-between">
                <span>0%</span>
                <span>Predictive Feeder Cleans</span>
                <span>80%</span>
              </div>
            </div>

            {/* Slider 3: Scrap reduction */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">AOI In-line Scrap Reduction:</span>
                <span className="font-mono text-purple-300 font-semibold">{scrapReductionPercent}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="75"
                step="5"
                value={scrapReductionPercent}
                onChange={(e) => setScrapReductionPercent(Number(e.target.value))}
                className="w-full accent-purple-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
              <div className="text-[10px] text-slate-500 flex justify-between">
                <span>0%</span>
                <span>Closed-loop 3D SPI feedback</span>
                <span>75%</span>
              </div>
            </div>
          </div>

          {/* Projected Outcomes Box */}
          <div className="p-4 bg-slate-950/70 border border-cyan-500/30 rounded-xl space-y-3">
            <div className="text-xs font-semibold text-slate-300">Projected Continuous Improvement ROI</div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-2.5 rounded bg-slate-900/80 border border-slate-800">
                <div className="text-slate-400 text-[11px]">Simulated New OEE</div>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-lg font-bold font-mono text-cyan-300 tabular-nums">
                    {projectedMetrics.newOee}%
                  </span>
                  <span className="text-[11px] font-mono text-emerald-400 font-bold">
                    +{projectedMetrics.oeeDelta}%
                  </span>
                </div>
              </div>

              <div className="p-2.5 rounded bg-slate-900/80 border border-slate-800">
                <div className="text-slate-400 text-[11px]">Extra Output / Shift</div>
                <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums mt-0.5">
                  +{projectedMetrics.extraUnitsPerShift} pcs
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded bg-emerald-950/20 border border-emerald-800/40 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-emerald-300 font-medium">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Estimated Annual Savings:</span>
              </div>
              <span className="font-mono text-emerald-400 font-bold text-sm tabular-nums">
                ${projectedMetrics.annualGains.toLocaleString()} / yr
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
