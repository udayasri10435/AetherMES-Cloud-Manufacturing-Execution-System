import React from 'react';
import { useMes } from '../context/MesContext';
import { Activity, Play, Pause, Plus, ShieldAlert } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenNewWo: () => void;
  onOpenCompare: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewWo,
  onOpenCompare,
}) => {
  const { isSimulating, toggleSimulation, quarantines } = useMes();

  const navLinks = [
    { id: 'floor', label: 'Shop Floor' },
    { id: 'oee', label: 'OEE & Losses' },
    { id: 'quality', label: 'Quality & SPC' },
    { id: 'genealogy', label: 'Genealogy & Trace' },
    { id: 'operator', label: 'Operator Station' },
  ];

  return (
    <header className="flex items-center justify-between px-6 py-3.5 bg-slate-900/90 border-b border-slate-800 backdrop-blur-md sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('floor');
          }}
          className="text-lg font-bold tracking-tight text-white flex items-center gap-2 hover:text-cyan-300 transition-colors"
        >
          <span className="w-2.5 h-2.5 rounded-sm bg-cyan-400 rotate-45 inline-block shadow-[0_0_8px_rgba(34,211,238,0.6)]" />
          AetherMES
        </a>
      </div>

      {/* Zone 2: 4–6 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
        {navLinks.map((link) => (
          <button
            key={link.id}
            onClick={() => setActiveTab(link.id)}
            className={`transition-colors whitespace-nowrap relative py-1 ${
              activeTab === link.id
                ? 'text-cyan-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {link.label}
            {activeTab === link.id && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 rounded-full" />
            )}
          </button>
        ))}
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-3">
        {quarantines.length > 0 && (
          <button
            onClick={() => setActiveTab('genealogy')}
            className="hidden lg:flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 transition-colors px-2 py-1 bg-amber-950/40 border border-amber-800/60 rounded"
            title="Active Quarantined Lots"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono tabular-nums">{quarantines.length}</span>
            <span>Lot Quarantine Active</span>
          </button>
        )}

        <button
          onClick={toggleSimulation}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 whitespace-nowrap ${
            isSimulating
              ? 'bg-slate-800/80 text-emerald-400 border-emerald-500/30 hover:bg-slate-800'
              : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200'
          }`}
          title={isSimulating ? 'Pause live shop floor telemetry' : 'Start live shop floor telemetry'}
        >
          {isSimulating ? (
            <>
              <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>Live Engine</span>
            </>
          ) : (
            <>
              <Pause className="w-3.5 h-3.5 text-slate-400" />
              <span>Paused</span>
            </>
          )}
        </button>

        <button
          onClick={onOpenCompare}
          className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 border border-slate-700 rounded-lg hover:bg-slate-700 transition-colors whitespace-nowrap hidden sm:inline-flex"
        >
          vs Legacy SAP / Rockwell
        </button>

        <button
          onClick={onOpenNewWo}
          className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors shadow-sm whitespace-nowrap flex items-center gap-1.5"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Dispatch Order</span>
        </button>
      </div>
    </header>
  );
};
