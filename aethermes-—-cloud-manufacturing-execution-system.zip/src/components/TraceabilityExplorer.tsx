import React, { useState } from 'react';
import { useMes } from '../context/MesContext';
import { GenealogyNode } from '../types/mes';
import {
  Search,
  GitBranch,
  ShieldAlert,
  CheckCircle2,
  FileText,
  Lock,
  Unlock,
  AlertTriangle,
  Building,
  User,
  Calendar,
  Layers,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Download,
} from 'lucide-react';

export const TraceabilityExplorer: React.FC = () => {
  const { genealogyDb, quarantines, quarantineLot, liftQuarantine } = useMes();

  const [searchQuery, setSearchQuery] = useState<string>('SN-EVB-883109-A');
  const [activeSerial, setActiveSerial] = useState<string>('SN-EVB-883109-A');
  const [collapsedNodes, setCollapsedNodes] = useState<Record<string, boolean>>({});
  const [showQuarantineModal, setShowQuarantineModal] = useState<boolean>(false);
  const [quarantineReason, setQuarantineReason] = useState<string>(
    'Vendor advisory: Micro-crack defect detected in raw wafer batch'
  );
  const [quarantineTargetLot, setQuarantineTargetLot] = useState<string>('LOT-MOSFET-4491');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  const currentTree: GenealogyNode | undefined = genealogyDb[activeSerial] || Object.values(genealogyDb)[0];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim();
    if (genealogyDb[query]) {
      setActiveSerial(query);
      return;
    }

    // Check if query matches a component lot anywhere in the database
    let foundSerial: string | null = null;
    const findLot = (node: GenealogyNode, serial: string) => {
      if (node.lotNumber.toLowerCase().includes(query.toLowerCase()) || node.identifier.toLowerCase().includes(query.toLowerCase())) {
        foundSerial = serial;
        return true;
      }
      if (node.children) {
        for (const child of node.children) {
          if (findLot(child, serial)) return true;
        }
      }
      return false;
    };

    for (const [serial, tree] of Object.entries(genealogyDb)) {
      if (findLot(tree, serial)) break;
    }

    if (foundSerial) {
      setActiveSerial(foundSerial);
    } else {
      alert(`No records found for query "${query}". Available sample serials: SN-EVB-883109-A or SN-INV-650-9942, or lot LOT-MOSFET-4491`);
    }
  };

  const toggleNode = (nodeId: string) => {
    setCollapsedNodes((prev) => ({ ...prev, [nodeId]: !prev[nodeId] }));
  };

  const handleTriggerQuarantine = () => {
    quarantineLot(
      quarantineTargetLot,
      quarantineReason,
      'Dual Power Trench MOSFET 40V 120A',
      'onsemi (Roznov Facility)'
    );
    setShowQuarantineModal(false);
  };

  const isLotQuarantined = (lotNum: string) => {
    return quarantines.some((q) => q.lotNumber === lotNum);
  };

  const handleExportDossier = () => {
    setExportNotice('Genealogy Compliance Dossier generated (ASIL-D / FDA 21 CFR Part 11 compliant). Ready for audit.');
    setTimeout(() => setExportNotice(null), 4000);
  };

  // Recursive tree renderer
  const renderNode = (node: GenealogyNode, depth: number = 0) => {
    const isCollapsed = collapsedNodes[node.id];
    const isQuarantined = isLotQuarantined(node.lotNumber);

    const typeBadge =
      node.type === 'finished_good'
        ? 'Finished Good'
        : node.type === 'subassembly'
        ? 'Subassembly'
        : 'Raw Component';

    return (
      <div key={node.id} className="relative">
        <div
          className={`p-3.5 rounded-xl border transition-all ${
            isQuarantined
              ? 'bg-rose-950/30 border-rose-600/70 shadow-lg'
              : node.type === 'finished_good'
              ? 'bg-slate-900 border-cyan-500/40 shadow'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div className="flex items-start gap-2.5">
              {node.children && node.children.length > 0 && (
                <button
                  onClick={() => toggleNode(node.id)}
                  className="mt-0.5 text-slate-400 hover:text-white p-0.5 rounded"
                >
                  {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
              )}

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-white">{node.identifier}</span>
                  <span className="text-[10px] text-slate-500 font-mono">[{typeBadge}]</span>
                  {isQuarantined && (
                    <span className="text-[10px] bg-rose-950 text-rose-300 border border-rose-800 px-1.5 py-0.2 rounded font-semibold uppercase">
                      Quarantine Locked
                    </span>
                  )}
                </div>
                <div className="text-sm font-semibold text-slate-200 mt-0.5">{node.name}</div>
                <div className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span>
                    Lot: <span className="font-mono text-cyan-300 font-semibold">{node.lotNumber}</span>
                  </span>
                  <span>·</span>
                  <span>Origin: {node.supplierOrStation}</span>
                  <span>·</span>
                  <span>Recorded: {node.timestamp}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center">
              {node.type === 'raw_material' && (
                <button
                  onClick={() => {
                    setQuarantineTargetLot(node.lotNumber);
                    setShowQuarantineModal(true);
                  }}
                  className={`px-2.5 py-1 text-xs rounded border transition-colors flex items-center gap-1 font-medium ${
                    isQuarantined
                      ? 'bg-rose-950 text-rose-400 border-rose-800 hover:bg-rose-900/60'
                      : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-rose-400 hover:border-rose-700'
                  }`}
                >
                  <ShieldAlert className="w-3 h-3" />
                  <span>{isQuarantined ? 'Quarantine Active' : 'Quarantine Lot'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Inspection and In-line Telemetry Metrics */}
          {node.inspectionMetrics && (
            <div className="mt-3 pt-2.5 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              {Object.entries(node.inspectionMetrics).map(([key, val]) => (
                <div key={key} className="bg-slate-950/60 p-2 rounded border border-slate-800/50">
                  <div className="text-[10px] text-slate-400">{key}</div>
                  <div className="font-mono text-slate-200 mt-0.5 truncate" title={val}>
                    {val}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Children Render */}
        {!isCollapsed && node.children && node.children.length > 0 && (
          <div className="pl-6 sm:pl-8 ml-3 sm:ml-4 border-l border-slate-800/80 mt-3 space-y-3">
            {node.children.map((child) => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Search & Actions */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        <div>
          <h2 className="text-base font-semibold text-white">End-to-End Product Genealogy & Lot Traceability</h2>
          <div className="text-xs text-slate-400">
            Backward & forward trace · Supplier wafer to finished vehicle serial · Instant recall quarantine
          </div>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex items-center gap-2 w-full lg:w-auto">
          <div className="relative flex-1 lg:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Serial, PCBA or Lot..."
              className="w-full bg-slate-950 border border-slate-700 text-xs text-slate-100 pl-9 pr-3 py-2 rounded-lg focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>
          <button
            type="submit"
            className="px-3.5 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors whitespace-nowrap"
          >
            Trace
          </button>
        </form>
      </div>

      {exportNotice && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-700/60 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{exportNotice}</span>
          </div>
          <span className="text-[10px] font-mono text-emerald-400">SHA256: e8b9...f402</span>
        </div>
      )}

      {/* Active Quarantines Banner */}
      {quarantines.length > 0 && (
        <div className="p-4 bg-rose-950/30 border border-rose-800/80 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-rose-300 font-semibold text-xs">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Active Electronic Containment Lock ({quarantines.length} Lots)</span>
            </div>
            <span className="text-[11px] text-rose-400 font-mono">ERP & WMS Dispatch Block Active</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
            {quarantines.map((q) => (
              <div key={q.lotNumber} className="p-3 rounded-lg bg-rose-950/40 border border-rose-800/60 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-white font-bold">{q.lotNumber}</span>
                  <button
                    onClick={() => liftQuarantine(q.lotNumber)}
                    className="text-[11px] text-emerald-400 hover:underline font-medium"
                  >
                    Lift Quarantine
                  </button>
                </div>
                <div className="text-slate-300 font-medium">{q.componentName}</div>
                <div className="text-rose-300 text-[11px]">{q.reason}</div>
                <div className="text-slate-400 text-[11px] flex justify-between pt-1 font-mono">
                  <span>Locked Serials: {q.affectedSerialsCount} pcs</span>
                  <span>{q.quarantinedAt}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Search Preset Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-500 whitespace-nowrap">Sample Units:</span>
        <button
          onClick={() => {
            setSearchQuery('SN-EVB-883109-A');
            setActiveSerial('SN-EVB-883109-A');
          }}
          className={`px-3 py-1.5 rounded-lg border font-mono transition-colors whitespace-nowrap ${
            activeSerial === 'SN-EVB-883109-A'
              ? 'bg-cyan-500/20 text-cyan-300 border-cyan-600/60 font-semibold'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          SN-EVB-883109-A (EV Battery ECU)
        </button>
        <button
          onClick={() => {
            setSearchQuery('SN-INV-650-9942');
            setActiveSerial('SN-INV-650-9942');
          }}
          className={`px-3 py-1.5 rounded-lg border font-mono transition-colors whitespace-nowrap ${
            activeSerial === 'SN-INV-650-9942'
              ? 'bg-cyan-500/20 text-cyan-300 border-cyan-600/60 font-semibold'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          SN-INV-650-9942 (650V Inverter)
        </button>

        <div className="ml-auto">
          <button
            onClick={handleExportDossier}
            className="px-3 py-1.5 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Audit Dossier</span>
          </button>
        </div>
      </div>

      {/* Genealogy Tree Graph Visualization */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Full Genealogy As-Built Tree Hierarchy</h3>
          </div>
          <div className="text-xs text-slate-400">
            Click chevron to expand/collapse sub-branches
          </div>
        </div>

        {currentTree ? (
          <div className="space-y-4 pt-2">{renderNode(currentTree)}</div>
        ) : (
          <div className="p-8 text-center text-slate-500 text-xs">No genealogy data found for this unit.</div>
        )}
      </div>

      {/* Quarantine Modal */}
      {showQuarantineModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 max-w-md w-full rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-400" />
                  Initiate Emergency Lot Quarantine
                </h3>
                <div className="text-xs text-slate-400 mt-1">
                  Freeze all WIP, warehouse stock, and dispatch for Lot: <span className="text-cyan-300 font-mono font-semibold">{quarantineTargetLot}</span>
                </div>
              </div>
              <button
                onClick={() => setShowQuarantineModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1">Quarantine Justification / Reason</label>
                <textarea
                  rows={3}
                  value={quarantineReason}
                  onChange={(e) => setQuarantineReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 text-white text-xs p-2.5 rounded-lg focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-800/40 text-xs text-amber-300 space-y-1">
                <div className="font-semibold">Automated Containment Actions:</div>
                <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-amber-200">
                  <li>Halts active pick & place feeders loading this reel</li>
                  <li>Flags 64 finished units in warehouse staging as Ship-Hold</li>
                  <li>Generates IATF 16949 / ISO 9001 containment record</li>
                </ul>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowQuarantineModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleTriggerQuarantine}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors"
              >
                Execute Quarantine Lock
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
