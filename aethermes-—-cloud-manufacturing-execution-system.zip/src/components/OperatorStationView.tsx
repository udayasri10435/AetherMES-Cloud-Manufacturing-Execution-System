import React, { useState, useEffect } from 'react';
import { useMes } from '../context/MesContext';
import {
  CheckCircle2,
  XCircle,
  AlertOctagon,
  Scan,
  Wrench,
  User,
  Clock,
  ShieldCheck,
  Radio,
  FileCheck,
  Volume2,
} from 'lucide-react';

interface OperatorStationViewProps {
  initialLineId?: string;
}

export const OperatorStationView: React.FC<OperatorStationViewProps> = ({ initialLineId }) => {
  const {
    lines,
    activeLineId,
    selectLine,
    activeLine,
    activeWorkOrder,
    recordGoodUnit,
    recordScrapUnit,
    completeStep,
    triggerMicroStoppage,
  } = useMes();

  const [scanSerial, setScanSerial] = useState<string>('SN-EVB-883109-A');
  const [paramValues, setParamValues] = useState<Record<string, string>>({});
  const [showScrapModal, setShowScrapModal] = useState<boolean>(false);
  const [scrapReason, setScrapReason] = useState<string>('Solder Bridging / Short (AOI Gate)');
  const [andonStatus, setAndonStatus] = useState<string | null>(null);
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  // Pick the line matching initialLineId if provided
  useEffect(() => {
    if (initialLineId && initialLineId !== activeLineId) {
      selectLine(initialLineId);
    }
  }, [initialLineId, activeLineId, selectLine]);

  // Current active step
  const activeStep = activeWorkOrder?.steps.find((s) => s.status === 'in_progress') || activeWorkOrder?.steps[0];

  // Initialize parameter inputs
  useEffect(() => {
    if (activeStep) {
      const initial: Record<string, string> = {};
      activeStep.parameters.forEach((p) => {
        initial[p.name] = p.actual || p.target;
      });
      setParamValues(initial);
    }
  }, [activeStep]);

  const handleSimulateScan = () => {
    const randomSerial = `SN-EVB-883${Math.floor(100 + Math.random() * 899)}-A`;
    setScanSerial(randomSerial);
    setFeedbackNotice(`Scanned barcode: ${randomSerial}`);
    setTimeout(() => setFeedbackNotice(null), 3000);
  };

  const handleCompleteStep = () => {
    if (!activeWorkOrder || !activeStep) return;

    const evaluatedParams = activeStep.parameters.map((p) => {
      const entered = paramValues[p.name] || p.target;
      return {
        name: p.name,
        actual: entered,
        passed: true,
      };
    });

    completeStep(activeWorkOrder.id, activeStep.id, evaluatedParams);
    recordGoodUnit(activeLine.id);
    setFeedbackNotice(`Step "${activeStep.name}" verified and logged. Good piece counted!`);
    setTimeout(() => setFeedbackNotice(null), 3500);

    // Generate next serial for next scan
    setScanSerial(`SN-EVB-883${Math.floor(100 + Math.random() * 899)}-A`);
  };

  const handleConfirmScrap = () => {
    recordScrapUnit(activeLine.id, scrapReason);
    setShowScrapModal(false);
    setFeedbackNotice(`Scrap logged: ${scrapReason}`);
    setTimeout(() => setFeedbackNotice(null), 3500);
  };

  const triggerAndonCord = (team: string) => {
    setAndonStatus(`ANDON ALERT: ${team} summoned to ${activeLine.name}`);
    triggerMicroStoppage(activeLine.id, `Andon Cord Pulled: ${team} required`);
    setTimeout(() => setAndonStatus(null), 6000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Station Selector & Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/80 p-4 rounded-2xl border border-slate-800 shadow-md">
        <div>
          <div className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">
            Operator Shopfloor Kiosk Terminal
          </div>
          <h2 className="text-lg font-bold text-white mt-0.5">{activeLine.name}</h2>
          <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
            <span>Operator:</span>
            <span className="text-white font-medium">{activeLine.operator}</span>
            <span>·</span>
            <span>Area: {activeLine.area}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Switch Station:</span>
          <select
            value={activeLineId}
            onChange={(e) => selectLine(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-xs text-white rounded-lg px-3 py-2 font-medium focus:outline-none focus:border-cyan-500"
          >
            {lines.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {feedbackNotice && (
        <div className="p-3.5 bg-cyan-950/60 border border-cyan-500/80 rounded-xl text-xs font-medium text-cyan-200 flex items-center gap-2 shadow-lg animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{feedbackNotice}</span>
        </div>
      )}

      {andonStatus && (
        <div className="p-4 bg-amber-950/70 border border-amber-500 rounded-xl text-xs font-bold text-amber-200 flex items-center gap-3 shadow-lg animate-pulse">
          <AlertOctagon className="w-5 h-5 text-amber-400 shrink-0" />
          <span>{andonStatus}</span>
        </div>
      )}

      {/* Main Kiosk Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: Scanner & Current Step Instructions (7 cols) */}
        <div className="md:col-span-7 space-y-4">
          {/* Barcode Scanner Input */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Scan className="w-4 h-4 text-cyan-400" />
                <span>Unit Barcode / GS1 DataMatrix Scan</span>
              </label>
              <button
                type="button"
                onClick={handleSimulateScan}
                className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
              >
                <span>Simulate Scanner Tap</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={scanSerial}
                onChange={(e) => setScanSerial(e.target.value)}
                placeholder="Scan or enter Serial..."
                className="w-full bg-slate-950 border border-slate-700 text-white font-mono text-sm px-4 py-2.5 rounded-xl focus:outline-none focus:border-cyan-500"
              />
              <button
                onClick={handleSimulateScan}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium rounded-xl border border-slate-700 whitespace-nowrap"
              >
                Scan Gun
              </button>
            </div>
            <div className="text-[11px] text-slate-500 flex items-center gap-2">
              <span>Lot: {activeWorkOrder?.lotNumber || 'LOT-2026-09A'}</span>
              <span>·</span>
              <span>SKU: {activeWorkOrder?.partNumber}</span>
            </div>
          </div>

          {/* Active Operation Checklist & Parameters */}
          {activeStep ? (
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="border-b border-slate-800 pb-3 flex items-start justify-between">
                <div>
                  <div className="text-[11px] font-mono text-cyan-400">Step {activeStep.stepNumber} of {activeWorkOrder?.steps.length}</div>
                  <h3 className="text-base font-bold text-white mt-0.5">{activeStep.name}</h3>
                  <div className="text-xs text-slate-400 mt-1">Station: {activeStep.station}</div>
                </div>

                <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  Target: {activeStep.cycleTimeSec}s
                </span>
              </div>

              {/* Standard Operating Procedure (SOP) Tools */}
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1.5">
                <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Wrench className="w-3.5 h-3.5 text-slate-400" />
                  <span>Mandatory Calibrated Tooling</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {activeStep.toolsRequired.map((tool, idx) => (
                    <span key={idx} className="text-xs font-mono text-slate-300 bg-slate-900 px-2 py-1 rounded border border-slate-800">
                      {tool}
                    </span>
                  ))}
                </div>
              </div>

              {/* In-line Inspection Parameters */}
              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-300">In-Line Measured Critical Tolerances</div>

                {activeStep.parameters.map((param, idx) => (
                  <div key={idx} className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
                    <div className="flex justify-between text-xs">
                      <span className="text-white font-medium">{param.name}</span>
                      <span className="font-mono text-slate-400 text-[11px]">
                        Target: {param.target} {param.unit} (Tol: {param.tolerance})
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={paramValues[param.name] || ''}
                        onChange={(e) =>
                          setParamValues((prev) => ({ ...prev, [param.name]: e.target.value }))
                        }
                        className="w-full bg-slate-900 border border-slate-700 text-white font-mono text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-cyan-500"
                        placeholder={param.target}
                      />
                      <span className="text-xs font-mono text-slate-400">{param.unit}</span>
                      <span className="text-emerald-400 text-xs font-bold font-mono">PASS</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-400 text-xs bg-slate-900/60 rounded-2xl border border-slate-800">
              All routing steps for this work order are complete.
            </div>
          )}
        </div>

        {/* Right Column: Big Touch Targets (5 cols) */}
        <div className="md:col-span-5 space-y-4">
          {/* Big Action Buttons */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Workstation Execution Controls
            </div>

            {/* Huge Green Complete Button */}
            <button
              onClick={handleCompleteStep}
              className="w-full py-5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-2xl shadow-lg transition-transform active:scale-95 flex flex-col items-center justify-center gap-1.5"
            >
              <div className="flex items-center gap-2 text-base">
                <CheckCircle2 className="w-6 h-6" />
                <span>PASS & ADVANCE PART</span>
              </div>
              <span className="text-xs font-semibold opacity-80">
                Log good unit & advance electronic traveler
              </span>
            </button>

            {/* Red Log Scrap Button */}
            <button
              onClick={() => setShowScrapModal(true)}
              className="w-full py-3.5 px-4 bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2 text-sm"
            >
              <XCircle className="w-4 h-4 text-rose-400" />
              <span>LOG SCRAP / DEFECT</span>
            </button>

            {/* Andon Cord Dispatch Buttons */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                <AlertOctagon className="w-3.5 h-3.5" />
                <span>Andon Assistance Cord</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => triggerAndonCord('Material Feeder Kitting')}
                  className="p-2.5 bg-slate-950 hover:bg-amber-950/40 text-slate-300 hover:text-amber-300 border border-slate-800 rounded-lg text-xs font-medium text-center transition-colors"
                >
                  Material Starvation
                </button>
                <button
                  onClick={() => triggerAndonCord('Maintenance Technician')}
                  className="p-2.5 bg-slate-950 hover:bg-amber-950/40 text-slate-300 hover:text-amber-300 border border-slate-800 rounded-lg text-xs font-medium text-center transition-colors"
                >
                  Tool / Maint Break
                </button>
                <button
                  onClick={() => triggerAndonCord('Quality Engineer')}
                  className="p-2.5 bg-slate-950 hover:bg-amber-950/40 text-slate-300 hover:text-amber-300 border border-slate-800 rounded-lg text-xs font-medium text-center transition-colors"
                >
                  Quality Inspector
                </button>
              </div>
            </div>
          </div>

          {/* Shift Counters Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="text-xs font-semibold text-slate-400">Shift Station Output</div>
            <div className="grid grid-cols-2 gap-3 font-mono">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-slate-500 text-[11px] font-sans">Units Produced</div>
                <div className="text-2xl font-bold text-white tabular-nums mt-0.5">
                  {activeLine.producedUnits}
                </div>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-slate-500 text-[11px] font-sans">Scrapped</div>
                <div className="text-2xl font-bold text-rose-400 tabular-nums mt-0.5">
                  {activeLine.scrappedUnits}
                </div>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 text-center font-mono">
              Shift Takt Target: {activeLine.targetShiftUnits} pcs · OEE: {activeLine.oee}%
            </div>
          </div>
        </div>
      </div>

      {/* Scrap Logging Modal */}
      {showScrapModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 max-w-md w-full rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-rose-400" />
                  Record Scrap Defect at {activeLine.name}
                </h3>
                <div className="text-xs text-slate-400 mt-1">Serial: {scanSerial}</div>
              </div>
              <button
                onClick={() => setShowScrapModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-slate-300 font-medium">Select Defect Reason Code</label>
              {[
                'Solder Bridging / Short (AOI Gate)',
                'Component Tombstoning (0201 Passives)',
                'Insufficient Solder Volume / Voiding',
                'Terminal Pin Misalignment / Coplanarity',
                'PCB Surface Scratch / Soldermask Peel',
                'Operator Handling Damage',
              ].map((reason) => (
                <button
                  key={reason}
                  onClick={() => setScrapReason(reason)}
                  className={`w-full text-left p-2.5 rounded-lg text-xs transition-colors border ${
                    scrapReason === reason
                      ? 'bg-rose-950/60 text-rose-300 border-rose-600/80 font-semibold'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {reason}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowScrapModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmScrap}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-lg transition-colors"
              >
                Confirm Scrap
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
