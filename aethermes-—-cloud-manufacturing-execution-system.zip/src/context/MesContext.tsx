import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  ProductionLine,
  WorkOrder,
  MachineLoss,
  SpcMeasurement,
  DefectItem,
  NcrReport,
  GenealogyNode,
  QuarantinedLot,
  LineStatus,
} from '../types/mes';
import {
  INITIAL_LINES,
  INITIAL_WORK_ORDERS,
  INITIAL_SIX_BIG_LOSSES,
  INITIAL_SPC_DATA,
  INITIAL_DEFECT_PARETO,
  INITIAL_NCRS,
  INITIAL_GENEALOGY_DATABASE,
  INITIAL_QUARANTINES,
} from '../data/initialData';

interface MesContextType {
  lines: ProductionLine[];
  workOrders: WorkOrder[];
  activeLineId: string;
  activeLine: ProductionLine;
  activeWorkOrder?: WorkOrder;
  sixBigLosses: MachineLoss[];
  spcData: SpcMeasurement[];
  defects: DefectItem[];
  ncrs: NcrReport[];
  genealogyDb: Record<string, GenealogyNode>;
  quarantines: QuarantinedLot[];
  isSimulating: boolean;
  simulationSpeed: number;
  plantOverallOee: number;
  plantAvailability: number;
  plantPerformance: number;
  plantQuality: number;
  totalProducedShift: number;
  totalScrapShift: number;
  firstPassYield: number;
  selectLine: (lineId: string) => void;
  setLineStatus: (lineId: string, status: LineStatus, anomaly?: string) => void;
  recordGoodUnit: (lineId: string, stepId?: string) => void;
  recordScrapUnit: (lineId: string, reason: string, stepId?: string) => void;
  completeStep: (
    workOrderId: string,
    stepId: string,
    parameters: { name: string; actual: string; passed: boolean }[]
  ) => void;
  dispatchWorkOrder: (wo: Partial<WorkOrder>) => void;
  logNcr: (ncr: Omit<NcrReport, 'id' | 'timestamp'>) => void;
  quarantineLot: (lotNumber: string, reason: string, componentName: string, supplier: string) => void;
  liftQuarantine: (lotNumber: string) => void;
  addSpcMeasurement: (value: number, lotNumber?: string) => void;
  toggleSimulation: () => void;
  setSimulationSpeed: (speed: number) => void;
  triggerMicroStoppage: (lineId: string, reason: string) => void;
  resolveStoppage: (lineId: string) => void;
}

const MesContext = createContext<MesContextType | undefined>(undefined);

export const MesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lines, setLines] = useState<ProductionLine[]>(INITIAL_LINES);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(INITIAL_WORK_ORDERS);
  const [activeLineId, setActiveLineId] = useState<string>('LINE-01');
  const [sixBigLosses, setSixBigLosses] = useState<MachineLoss[]>(INITIAL_SIX_BIG_LOSSES);
  const [spcData, setSpcData] = useState<SpcMeasurement[]>(INITIAL_SPC_DATA);
  const [defects, setDefects] = useState<DefectItem[]>(INITIAL_DEFECT_PARETO);
  const [ncrs, setNcrs] = useState<NcrReport[]>(INITIAL_NCRS);
  const [genealogyDb, setGenealogyDb] = useState<Record<string, GenealogyNode>>(INITIAL_GENEALOGY_DATABASE);
  const [quarantines, setQuarantines] = useState<QuarantinedLot[]>(INITIAL_QUARANTINES);
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);

  const activeLine = useMemo(() => {
    return lines.find((l) => l.id === activeLineId) || lines[0];
  }, [lines, activeLineId]);

  const activeWorkOrder = useMemo(() => {
    return workOrders.find((w) => w.id === activeLine.activeWorkOrderId);
  }, [workOrders, activeLine.activeWorkOrderId]);

  // Plant-wide metrics
  const plantOverallOee = useMemo(() => {
    const sum = lines.reduce((acc, l) => acc + l.oee, 0);
    return Number((sum / lines.length).toFixed(1));
  }, [lines]);

  const plantAvailability = useMemo(() => {
    const sum = lines.reduce((acc, l) => acc + l.availability, 0);
    return Number((sum / lines.length).toFixed(1));
  }, [lines]);

  const plantPerformance = useMemo(() => {
    const sum = lines.reduce((acc, l) => acc + l.performance, 0);
    return Number((sum / lines.length).toFixed(1));
  }, [lines]);

  const plantQuality = useMemo(() => {
    const sum = lines.reduce((acc, l) => acc + l.quality, 0);
    return Number((sum / lines.length).toFixed(1));
  }, [lines]);

  const totalProducedShift = useMemo(() => {
    return lines.reduce((acc, l) => acc + l.producedUnits, 0);
  }, [lines]);

  const totalScrapShift = useMemo(() => {
    return lines.reduce((acc, l) => acc + l.scrappedUnits, 0);
  }, [lines]);

  const firstPassYield = useMemo(() => {
    const total = totalProducedShift + totalScrapShift;
    if (total === 0) return 99.2;
    return Number(((totalProducedShift / total) * 100).toFixed(2));
  }, [totalProducedShift, totalScrapShift]);

  const selectLine = (lineId: string) => {
    setActiveLineId(lineId);
  };

  const setLineStatus = useCallback((lineId: string, status: LineStatus, anomaly?: string) => {
    setLines((prev) =>
      prev.map((l) => {
        if (l.id !== lineId) return l;
        const isDownOrHalted = status === 'down' || status === 'maintenance';
        const newAvailability = isDownOrHalted ? Math.max(50, l.availability - 4.5) : Math.min(99, l.availability + 1.2);
        const newOee = Number(((newAvailability * l.performance * l.quality) / 10000).toFixed(1));
        return {
          ...l,
          status,
          lastAnomaly: anomaly !== undefined ? anomaly : l.lastAnomaly,
          availability: Number(newAvailability.toFixed(1)),
          oee: newOee,
          downtimeMinutes: isDownOrHalted ? l.downtimeMinutes + 5 : l.downtimeMinutes,
        };
      })
    );
  }, []);

  const recordGoodUnit = useCallback((lineId: string) => {
    setLines((prev) =>
      prev.map((l) => {
        if (l.id !== lineId) return l;
        const newProduced = l.producedUnits + 1;
        const total = newProduced + l.scrappedUnits;
        const newQuality = Number(((newProduced / total) * 100).toFixed(1));
        const newOee = Number(((l.availability * l.performance * newQuality) / 10000).toFixed(1));
        return {
          ...l,
          producedUnits: newProduced,
          quality: newQuality,
          oee: newOee,
        };
      })
    );

    // Also update current active work order progress
    setWorkOrders((prev) =>
      prev.map((wo) => {
        const line = lines.find((l) => l.id === lineId);
        if (line && wo.id === line.activeWorkOrderId) {
          return {
            ...wo,
            completedQty: wo.completedQty + 1,
            status: wo.completedQty + 1 >= wo.plannedQty ? 'completed' : wo.status,
          };
        }
        return wo;
      })
    );
  }, [lines]);

  const recordScrapUnit = useCallback((lineId: string, reason: string) => {
    setLines((prev) =>
      prev.map((l) => {
        if (l.id !== lineId) return l;
        const newScrap = l.scrappedUnits + 1;
        const total = l.producedUnits + newScrap;
        const newQuality = Number(((l.producedUnits / total) * 100).toFixed(1));
        const newOee = Number(((l.availability * l.performance * newQuality) / 10000).toFixed(1));
        return {
          ...l,
          scrappedUnits: newScrap,
          quality: newQuality,
          oee: newOee,
          lastAnomaly: `Scrap logged: ${reason}`,
        };
      })
    );

    // Update defect pareto
    setDefects((prev) => {
      const match = prev.find((d) => d.category.toLowerCase().includes(reason.toLowerCase()) || reason.toLowerCase().includes(d.category.toLowerCase()));
      if (match) {
        return prev.map((d) => (d.id === match.id ? { ...d, count: d.count + 1 } : d));
      }
      return [
        {
          id: `D-${Date.now()}`,
          category: reason,
          count: 1,
          percentage: 1.0,
          cumulativePercent: 100.0,
          severity: 'minor',
          trend: 'up',
        },
        ...prev,
      ];
    });

    // Also update work order scrap count
    setWorkOrders((prev) =>
      prev.map((wo) => {
        const line = lines.find((l) => l.id === lineId);
        if (line && wo.id === line.activeWorkOrderId) {
          return {
            ...wo,
            scrapQty: wo.scrapQty + 1,
          };
        }
        return wo;
      })
    );
  }, [lines]);

  const completeStep = useCallback((
    workOrderId: string,
    stepId: string,
    parameters: { name: string; actual: string; passed: boolean }[]
  ) => {
    setWorkOrders((prev) =>
      prev.map((wo) => {
        if (wo.id !== workOrderId) return wo;
        const updatedSteps = wo.steps.map((st) => {
          if (st.id !== stepId) return st;
          const allPassed = parameters.every((p) => p.passed);
          return {
            ...st,
            status: (allPassed ? 'passed' : 'rejected') as any,
            timestamp: new Date().toLocaleTimeString(),
            parameters: st.parameters.map((p) => {
              const userVal = parameters.find((u) => u.name === p.name);
              if (userVal) {
                return { ...p, actual: userVal.actual, passed: userVal.passed };
              }
              return p;
            }),
          };
        });

        // Set next step to in_progress if current passed
        const currentIdx = updatedSteps.findIndex((s) => s.id === stepId);
        if (currentIdx !== -1 && currentIdx + 1 < updatedSteps.length) {
          if (updatedSteps[currentIdx].status === 'passed' && updatedSteps[currentIdx + 1].status === 'pending') {
            updatedSteps[currentIdx + 1].status = 'in_progress';
          }
        }

        return {
          ...wo,
          steps: updatedSteps,
        };
      })
    );
  }, []);

  const dispatchWorkOrder = useCallback((wo: Partial<WorkOrder>) => {
    const newId = `WO-${Math.floor(8800 + Math.random() * 1000)}`;
    const newWo: WorkOrder = {
      id: newId,
      partNumber: wo.partNumber || 'SKU-NEW-8800',
      partName: wo.partName || 'Custom Industrial Electronics Unit',
      revision: wo.revision || 'Rev A.1',
      lotNumber: wo.lotNumber || `LOT-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      status: 'scheduled',
      priority: wo.priority || 'normal',
      plannedQty: wo.plannedQty || 500,
      completedQty: 0,
      scrapQty: 0,
      targetTaktSec: wo.targetTaktSec || 25.0,
      lineId: wo.lineId || 'LINE-01',
      dueDate: wo.dueDate || '2026-10-15',
      steps: wo.steps || [
        {
          id: 'S1',
          stepNumber: 10,
          name: 'Material Kitting & Verification',
          station: 'KIT-BAY-1',
          status: 'pending',
          cycleTimeSec: 15,
          toolsRequired: ['Handheld Scanner GS1'],
          parameters: [{ name: 'Lot Barcode Verified', target: 'Match BOM', tolerance: '100%', unit: 'bool' }],
        },
        {
          id: 'S2',
          stepNumber: 20,
          name: 'Primary SMT Assembly',
          station: 'SMT-PnP-01',
          status: 'pending',
          cycleTimeSec: 25,
          toolsRequired: ['Feeder A1-A12'],
          parameters: [{ name: 'Solder Coplanarity', target: '100', tolerance: '±10', unit: 'µm' }],
        },
        {
          id: 'S3',
          stepNumber: 30,
          name: 'Quality Gate & Packaging',
          station: 'QC-GATE-01',
          status: 'pending',
          cycleTimeSec: 20,
          toolsRequired: ['Optical Scope'],
          parameters: [{ name: 'Visual Inspection', target: 'Zero Flaws', tolerance: 'IPC-A-610 Class 3', unit: 'grade' }],
        },
      ],
      bomComponents: wo.bomComponents || [
        {
          componentId: 'COMP-RAW-01',
          description: 'Standard Silicon Bare Die',
          requiredQtyPerUnit: 1,
          consumedLot: 'LOT-RAW-8812',
          supplier: 'Semiconductor Global',
        },
      ],
    };

    setWorkOrders((prev) => [newWo, ...prev]);

    // If assigned to a line that is idle or has no WO, assign it
    setLines((prev) =>
      prev.map((l) => {
        if (l.id === newWo.lineId && (!l.activeWorkOrderId || l.status === 'idle')) {
          return {
            ...l,
            activeWorkOrderId: newId,
            status: 'running',
          };
        }
        return l;
      })
    );
  }, []);

  const logNcr = useCallback((ncr: Omit<NcrReport, 'id' | 'timestamp'>) => {
    const newNcr: NcrReport = {
      ...ncr,
      id: `NCR-2026-${String(Math.floor(50 + Math.random() * 900)).padStart(3, '0')}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setNcrs((prev) => [newNcr, ...prev]);
  }, []);

  const quarantineLot = useCallback((lotNumber: string, reason: string, componentName: string, supplier: string) => {
    const newQuarantine: QuarantinedLot = {
      lotNumber,
      componentName,
      supplier,
      quarantinedAt: new Date().toISOString().replace('T', ' ').substring(0, 16) + ' UTC',
      reason,
      affectedSerialsCount: Math.floor(25 + Math.random() * 80),
      lockedWorkOrders: ['WO-8821', 'WO-8822'].filter((_, i) => i === 0 || Math.random() > 0.5),
    };

    setQuarantines((prev) => [newQuarantine, ...prev.filter((q) => q.lotNumber !== lotNumber)]);

    // Mark affected work orders as quality_hold
    setWorkOrders((prev) =>
      prev.map((wo) => {
        const containsLot = wo.bomComponents.some((c) => c.consumedLot === lotNumber) || wo.lotNumber === lotNumber;
        if (containsLot) {
          return { ...wo, status: 'quality_hold' };
        }
        return wo;
      })
    );
  }, []);

  const liftQuarantine = useCallback((lotNumber: string) => {
    setQuarantines((prev) => prev.filter((q) => q.lotNumber !== lotNumber));
    setWorkOrders((prev) =>
      prev.map((wo) => {
        if (wo.status === 'quality_hold' && (wo.lotNumber === lotNumber || wo.bomComponents.some((c) => c.consumedLot === lotNumber))) {
          return { ...wo, status: 'in_progress' };
        }
        return wo;
      })
    );
  }, []);

  const addSpcMeasurement = useCallback((value: number, lotNumber?: string) => {
    setSpcData((prev) => {
      const nextIndex = prev.length + 1;
      const isViolating = value > 12.32 || value < 11.68;
      const newMeasurement: SpcMeasurement = {
        id: `S${nextIndex}`,
        sampleIndex: nextIndex,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        lotNumber: lotNumber || 'LOT-2026-09A',
        value: Number(value.toFixed(2)),
        meanSubgroup: Number(((value + 12.0) / 2).toFixed(2)),
        rangeSubgroup: Number(Math.abs(value - 12.0).toFixed(2)),
        isViolation: isViolating,
        violationReason: isViolating ? `Value ${value.toFixed(2)}mm outside 3σ control limits (11.68 - 12.32mm)` : undefined,
      };
      return [...prev, newMeasurement];
    });
  }, []);

  const triggerMicroStoppage = useCallback((lineId: string, reason: string) => {
    setLineStatus(lineId, 'down', reason);
    setSixBigLosses((prev) =>
      prev.map((loss) => {
        if (loss.category === 'breakdown' || loss.category === 'minor_stoppage') {
          return {
            ...loss,
            minutes: loss.minutes + 12,
            impactPercent: Number((loss.impactPercent + 1.2).toFixed(1)),
          };
        }
        return loss;
      })
    );
  }, [setLineStatus]);

  const resolveStoppage = useCallback((lineId: string) => {
    setLineStatus(lineId, 'running', undefined);
  }, [setLineStatus]);

  const toggleSimulation = () => {
    setIsSimulating((prev) => !prev);
  };

  // Real-time Shop Floor background simulation heartbeat
  useEffect(() => {
    if (!isSimulating) return;

    const intervalTime = Math.max(1200 / simulationSpeed, 400);
    const interval = setInterval(() => {
      setLines((prev) =>
        prev.map((line) => {
          if (line.status !== 'running') return line;

          // Realistic micro-fluctuations in sensor readings
          const tempDelta = (Math.random() - 0.5) * 0.3;
          const vibDelta = (Math.random() - 0.5) * 0.04;
          const cycleDelta = (Math.random() - 0.5) * 0.4;

          const currentCycle = Math.max(line.plannedTaktSec * 0.85, Number((line.currentCycleSec + cycleDelta).toFixed(1)));
          
          // Every ~40 cycles, produce 1 unit on running lines
          const shouldProduce = Math.random() < 0.28 * simulationSpeed;
          const isScrap = shouldProduce && Math.random() < 0.015; // 1.5% defect rate

          const newProduced = shouldProduce && !isScrap ? line.producedUnits + 1 : line.producedUnits;
          const newScrap = isScrap ? line.scrappedUnits + 1 : line.scrappedUnits;
          const total = newProduced + newScrap;
          const newQuality = total > 0 ? Number(((newProduced / total) * 100).toFixed(1)) : line.quality;

          // Re-calculate OEE
          const newOee = Number(((line.availability * line.performance * newQuality) / 10000).toFixed(1));

          return {
            ...line,
            currentCycleSec: currentCycle,
            producedUnits: newProduced,
            scrappedUnits: newScrap,
            quality: newQuality,
            oee: newOee,
            stationSensors: {
              tempC: Number((line.stationSensors.tempC + tempDelta).toFixed(1)),
              vibrationMmS: Number(Math.max(0.1, line.stationSensors.vibrationMmS + vibDelta).toFixed(2)),
              pneumaticBar: line.stationSensors.pneumaticBar,
            },
          };
        })
      );
    }, intervalTime);

    return () => clearInterval(interval);
  }, [isSimulating, simulationSpeed]);

  return (
    <MesContext.Provider
      value={{
        lines,
        workOrders,
        activeLineId,
        activeLine,
        activeWorkOrder,
        sixBigLosses,
        spcData,
        defects,
        ncrs,
        genealogyDb,
        quarantines,
        isSimulating,
        simulationSpeed,
        plantOverallOee,
        plantAvailability,
        plantPerformance,
        plantQuality,
        totalProducedShift,
        totalScrapShift,
        firstPassYield,
        selectLine,
        setLineStatus,
        recordGoodUnit,
        recordScrapUnit,
        completeStep,
        dispatchWorkOrder,
        logNcr,
        quarantineLot,
        liftQuarantine,
        addSpcMeasurement,
        toggleSimulation,
        setSimulationSpeed,
        triggerMicroStoppage,
        resolveStoppage,
      }}
    >
      {children}
    </MesContext.Provider>
  );
};

export const useMes = () => {
  const context = useContext(MesContext);
  if (!context) {
    throw new Error('useMes must be used within a MesProvider');
  }
  return context;
};
