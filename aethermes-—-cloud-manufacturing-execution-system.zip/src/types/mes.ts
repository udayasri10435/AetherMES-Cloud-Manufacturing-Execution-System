export type LineStatus = 'running' | 'idle' | 'down' | 'changeover' | 'maintenance';

export type PriorityLevel = 'critical' | 'high' | 'normal' | 'low';

export type WorkOrderStatus = 'scheduled' | 'in_progress' | 'quality_hold' | 'completed';

export type StepStatus = 'pending' | 'in_progress' | 'passed' | 'rework' | 'rejected';

export interface OperationStep {
  id: string;
  stepNumber: number;
  name: string;
  station: string;
  status: StepStatus;
  operator?: string;
  cycleTimeSec: number;
  actualCycleTimeSec?: number;
  toolsRequired: string[];
  parameters: {
    name: string;
    target: string;
    actual?: string;
    tolerance: string;
    unit: string;
    passed?: boolean;
  }[];
  timestamp?: string;
}

export interface WorkOrder {
  id: string;
  partNumber: string;
  partName: string;
  revision: string;
  lotNumber: string;
  status: WorkOrderStatus;
  priority: PriorityLevel;
  plannedQty: number;
  completedQty: number;
  scrapQty: number;
  targetTaktSec: number;
  lineId: string;
  dueDate: string;
  steps: OperationStep[];
  bomComponents: {
    componentId: string;
    description: string;
    requiredQtyPerUnit: number;
    consumedLot: string;
    supplier: string;
  }[];
}

export interface MachineLoss {
  category: 'breakdown' | 'setup_changeover' | 'minor_stoppage' | 'reduced_speed' | 'process_defect' | 'yield_loss';
  name: string;
  minutes: number;
  impactPercent: number;
  reasonCode: string;
}

export interface ProductionLine {
  id: string;
  name: string;
  area: string;
  status: LineStatus;
  activeWorkOrderId: string;
  currentStepName: string;
  operator: string;
  plannedTaktSec: number;
  currentCycleSec: number;
  targetShiftUnits: number;
  producedUnits: number;
  scrappedUnits: number;
  availability: number; // 0 - 100
  performance: number;  // 0 - 100
  quality: number;      // 0 - 100
  oee: number;          // A * P * Q / 10000
  uptimeMinutes: number;
  downtimeMinutes: number;
  lastAnomaly?: string;
  stationSensors: {
    tempC: number;
    vibrationMmS: number;
    pneumaticBar: number;
  };
}

export interface SpcMeasurement {
  id: string;
  sampleIndex: number;
  timestamp: string;
  lotNumber: string;
  value: number; // e.g. laser weld depth in mm
  meanSubgroup: number;
  rangeSubgroup: number;
  isViolation: boolean;
  violationReason?: string;
}

export interface DefectItem {
  id: string;
  category: string;
  count: number;
  percentage: number;
  cumulativePercent: number;
  severity: 'critical' | 'major' | 'minor';
  trend: 'up' | 'down' | 'steady';
}

export interface NcrReport {
  id: string;
  timestamp: string;
  workOrderId: string;
  lotNumber: string;
  defectCategory: string;
  qtyAffected: number;
  severity: 'critical' | 'major' | 'minor';
  status: 'open' | 'investigating' | 'contained' | 'closed';
  containmentAction: string;
  disposition: 'scrap' | 'rework' | 'vendor_return' | 'concession';
  engineerSignOff: string;
}

export interface GenealogyNode {
  id: string;
  type: 'finished_good' | 'subassembly' | 'raw_material' | 'process_record';
  identifier: string;
  name: string;
  lotNumber: string;
  supplierOrStation: string;
  timestamp: string;
  operator: string;
  status: 'passed' | 'quarantined' | 'flagged';
  inspectionMetrics?: Record<string, string>;
  children?: GenealogyNode[];
}

export interface QuarantinedLot {
  lotNumber: string;
  componentName: string;
  supplier: string;
  quarantinedAt: string;
  reason: string;
  affectedSerialsCount: number;
  lockedWorkOrders: string[];
}
